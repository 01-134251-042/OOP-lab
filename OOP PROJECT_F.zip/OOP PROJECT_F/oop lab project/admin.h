﻿#ifndef ADMIN_H
#define ADMIN_H

#include "User.h"
#include <vector>

class Student;
class Teacher;
class Course;

class Admin : public User {
private:
    string adminLevel;
    vector<Student*> students;      // Composition - Admin manages students
    vector<Teacher*> teachers;      // Composition - Admin manages teachers
    vector<Course*> courses;        // Composition - Admin manages courses

public:
    // ... other members
    Admin(int id = 0, string name = "", string email = "",
        string password = "", string adminLevel = "SuperAdmin");

    virtual ~Admin();

    string getAdminLevel() const;
    vector<Student*> getStudents() const;
    vector<Teacher*> getTeachers() const;
    vector<Course*> getCourses() const;

    void setAdminLevel(string level);

    // Functionality 1: Add Student
    bool addStudent(Student* student);

    // Functionality 2: Add Teacher
    bool addTeacher(Teacher* teacher);

    // Functionality 3: Remove User
    bool removeStudent(int studentId);
    bool removeTeacher(int teacherId);

    // Functionality 4: View All Users
    void viewAllUsers() const;

    // Functionality 5: System Statistics
    void displaySystemStatistics() const;

    // Polymorphism - Override virtual functions
    virtual void login() override;
    virtual void displayDashboard() override;
    virtual void displayMenu() override;

    virtual string toString() const override;
    static Admin* parseAdmin(const std::string& line);
    /// Declare free functions here (NOT member of Admin)

};

#endif // ADMIN_H#pragma once
