#include "Student.h"
#include "Course.h"
#include "Assignment.h"
#include <fstream>
#include <sstream>
#include <sstream>
#include <algorithm>
#include <iostream>
#include <filesystem>
namespace fs = std::filesystem;

const string PROJECT_ROOT = "D:/OOP PROJECT_F/oop lab project/";


Student::Student(int id, string name, string email, string password, int rollNumber, float gpa)
    : User(id, name, email, password, "Student"), rollNumber(rollNumber), gpa(gpa) {

    if (rollNumber < 0) throw invalid_argument("ERROR: Roll number cannot be negative");
    if (gpa < 0.0 || gpa > 4.0) throw invalid_argument("ERROR: GPA must be between 0.0 and 4.0");
}

Student::~Student() {
    enrolledCourses.clear();
    submissions.clear();
}

int Student::getRollNumber() const { return rollNumber; }
float Student::getGPA() const { return gpa; }
vector<Course*> Student::getEnrolledCourses() const { return enrolledCourses; }

void Student::setGPA(float g) {
    if (g < 0.0 || g > 4.0) throw invalid_argument("ERROR: GPA must be 0.0-4.0");
    gpa = g;
}

void Student::setRollNumber(int rn) {
    if (rn < 0) throw invalid_argument("ERROR: Roll number cannot be negative");
    rollNumber = rn;
}

// Functionality 1: View Enrolled Courses
void Student::viewEnrolledCourses() const {
    cout << "\n=== YOUR ENROLLED COURSES ===\n";
    if (enrolledCourses.empty()) {
        cout << "No courses enrolled.\n";
        return;
    }
    for (size_t i = 0; i < enrolledCourses.size(); i++) {
        cout << (i + 1) << ". Course\n";
    }
}

// Functionality 2: Download Notes
// Functionality 2: Download Notes
// Functionality 2: Download Notes
void Student::downloadNotes(int courseId) {
    string sourcePath = PROJECT_ROOT + "course_materials/course_" + to_string(courseId) + ".txt";
    string destPath = PROJECT_ROOT + "downloads/notes_course_" + to_string(courseId) + ".txt";

    // Ensure downloads directory exists
    if (!fs::exists(PROJECT_ROOT + "downloads")) {
        fs::create_directories(PROJECT_ROOT + "downloads");
    }

    if (fs::exists(sourcePath)) {
        try {
            if (fs::exists(destPath)) fs::remove(destPath);
            fs::copy_file(sourcePath, destPath);
            cout << "? Notes successfully downloaded to '" << destPath << "'\n";
        } catch (fs::filesystem_error& e) {
            cout << "Error downloading: " << e.what() << "\n";
        }
    } else {
        cout << "Error: No notes found for Course " << courseId << " (checked: " << sourcePath << ")\n";
    }
}

// Functionality 3: Submit Assignment
// Functionality 3: Submit Assignment
// Functionality 3: Submit Assignment
void Student::submitAssignment(int assignmentId, string file) {
    if (file.empty()) throw invalid_argument("ERROR: File path cannot be empty");

    fs::path inputPath(file);
    string sourcePath = file;
    
    // If path is relative, assume it's in the project root
    if (inputPath.is_relative()) {
        sourcePath = PROJECT_ROOT + file;
    }

    // Ensure submissions directory exists
    if (!fs::exists(PROJECT_ROOT + "submissions")) {
        fs::create_directories(PROJECT_ROOT + "submissions");
    }

    string destFilename = PROJECT_ROOT + "submissions/submission_" + to_string(id) + "_" + to_string(assignmentId) + fs::path(sourcePath).extension().string();
    
    if (fs::exists(sourcePath)) {
        try {
             if (fs::exists(destFilename)) fs::remove(destFilename);
             fs::copy_file(sourcePath, destFilename);
             cout << "? Assignment submitted! Copy saved to: " << destFilename << "\n";
        } catch (fs::filesystem_error& e) {
             throw runtime_error("File copy failed: " + string(e.what()));
        }
    } else {
        throw runtime_error("Source file not found: " + sourcePath);
    }
}

// Functionality 4: View Marks
void Student::viewMarks() const {
    cout << "\n=== YOUR MARKS ===\n";
    cout << "Current GPA: " << gpa << "/4.0\n";
}

// Functionality 5: Enroll in Course
void Student::enrollCourse(Course* course) {
    if (course == nullptr) throw invalid_argument("ERROR: Course cannot be null");

    auto it = find(enrolledCourses.begin(), enrolledCourses.end(), course);
    if (it != enrolledCourses.end()) {
        throw runtime_error("ERROR: Already enrolled in this course");
    }

    enrolledCourses.push_back(course);
    cout << "? Successfully enrolled in course!\n";
}

void Student::dropCourse(Course* course) {
    if (course == nullptr) throw invalid_argument("ERROR: Course cannot be null");

    auto it = remove(enrolledCourses.begin(), enrolledCourses.end(), course);
    if (it == enrolledCourses.end()) {
        throw runtime_error("ERROR: Not enrolled in this course");
    }

    enrolledCourses.erase(it, enrolledCourses.end());
    cout << "? Successfully dropped course!\n";
}

void Student::login() {
    cout << "\n******************************************\n";
    cout << " --- STUDENT LOGIN ---                 \n";
    cout << " ? Logged in: " << name << "\n";
    cout << " Roll: " << rollNumber << " | GPA: " << gpa << "\n";
    cout << "  ******************************************\n";
}

void Student::displayDashboard() {
    cout << "\n*****************************************\n";
    cout << "\n --- STUDENT DASHBOARD ---             \n";
    cout << "\n Name: " << name << "\n";
    cout << "\n Email: " << email << "\n";
    cout << "\n Roll: " << rollNumber << "\n";
    cout << "\n GPA: " << gpa << "/4.0\n";
    cout << "\n******************************************\n";
}

void Student::displayMenu() {
    cout << "\n=== STUDENT MENU ===\n";
    cout << "1. View Enrolled Courses\n";
    cout << "2. Download Notes\n";
    cout << "3. Submit Assignment\n";
    cout << "4. View Marks\n";
    cout << "5. Logout\n";
    cout << "Enter choice: ";
}
/*
string Student::toString() const {
    stringstream ss;
    ss << id << "|" << name << "|" << email << "|" << password
        << "|" << userType << "|" << rollNumber << "|" << gpa;
    return ss.str();
}
*/
Student* Student::parseStudent(string line) {
    stringstream ss(line);
    string token;
    int id, rollNumber;
    float gpa;
    string name, email, password, userType;

    try {
        getline(ss, token, '|'); id = stoi(token);
        getline(ss, name, '|');
        getline(ss, email, '|');
        getline(ss, password, '|');
        getline(ss, userType, '|');
        getline(ss, token, '|'); rollNumber = stoi(token);
        getline(ss, token, '|'); gpa = stof(token);

        return new Student(id, name, email, password, rollNumber, gpa);
    }
    catch (...) {
        return nullptr;
    }
}

string Student::toString() const {
   
    return to_string(getId()) + "|" + getName() + "|" + getEmail() + "|" + getPassword() + "|Student|" + to_string(rollNumber) + "|" + to_string(gpa) + "|";
}