#include "logindialog.h"
#include "lmsdatabase.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QMessageBox>
#include <QGroupBox>
#include <QSpacerItem>

LoginDialog::LoginDialog(QWidget *parent)
    : QDialog(parent), loggedInUser(nullptr)
{
    setupUI();
    applyStyles();
}

LoginDialog::~LoginDialog() {
}

void LoginDialog::setupUI() {
    setWindowTitle("LMS - Login");
    setFixedSize(550, 450);
    setModal(true);
    
    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(30);
    mainLayout->setContentsMargins(40, 40, 40, 40);
    
    // Title
    QLabel* titleLabel = new QLabel("Learning Management System", this);
    titleLabel->setAlignment(Qt::AlignCenter);
    titleLabel->setStyleSheet(
        "font-size: 26px; "
        "font-weight: bold; "
        "color: #60a5fa; "
        "padding: 20px; "
        "background: qlineargradient(x1:0, y1:0, x2:1, y2:0, "
        "stop:0 rgba(96, 165, 250, 0.15), stop:1 rgba(124, 58, 237, 0.15)); "
        "border-radius: 12px; "
        "border: 2px solid rgba(96, 165, 250, 0.3);"
    );
    mainLayout->addWidget(titleLabel);
    
    // Subtitle
    QLabel* subtitleLabel = new QLabel("Sign in to continue", this);
    subtitleLabel->setAlignment(Qt::AlignCenter);
    subtitleLabel->setStyleSheet("font-size: 14px; color: #94a3b8;");
    mainLayout->addWidget(subtitleLabel);
    
    // Add some spacing
    mainLayout->addSpacing(10);
    
    // Email field with label
    QLabel* emailLabel = new QLabel("Email Address", this);
    emailLabel->setStyleSheet("font-size: 13px; font-weight: 600; color: #cbd5e1; margin-bottom: 5px;");
    mainLayout->addWidget(emailLabel);
    
    emailEdit = new QLineEdit(this);
    emailEdit->setPlaceholderText("Enter your email");
    emailEdit->setObjectName("emailEdit");
    mainLayout->addWidget(emailEdit);
    
    // Add spacing between fields
    mainLayout->addSpacing(10);
    
    // Password field with label
    QLabel* passwordLabel = new QLabel("Password", this);
    passwordLabel->setStyleSheet("font-size: 13px; font-weight: 600; color: #cbd5e1; margin-bottom: 5px;");
    mainLayout->addWidget(passwordLabel);
    
    passwordEdit = new QLineEdit(this);
    passwordEdit->setPlaceholderText("Enter your password");
    passwordEdit->setEchoMode(QLineEdit::Password);
    passwordEdit->setObjectName("passwordEdit");
    mainLayout->addWidget(passwordEdit);
    
    // Add spacing before buttons
    mainLayout->addSpacing(15);
    
    // Buttons
    QHBoxLayout* buttonLayout = new QHBoxLayout();
    buttonLayout->setSpacing(15);
    
    loginButton = new QPushButton("Login", this);
    loginButton->setObjectName("loginButton");
    loginButton->setCursor(Qt::PointingHandCursor);
    buttonLayout->addWidget(loginButton);
    
    createAccountButton = new QPushButton("Create Account", this);
    createAccountButton->setCursor(Qt::PointingHandCursor);
    buttonLayout->addWidget(createAccountButton);
    
    mainLayout->addLayout(buttonLayout);
    
    // Add stretch to push everything to the top
    mainLayout->addStretch();
    
    // Connect signals
    connect(loginButton, &QPushButton::clicked, this, &LoginDialog::onLoginClicked);
    connect(createAccountButton, &QPushButton::clicked, this, &LoginDialog::onCreateAccountClicked);
    connect(emailEdit, &QLineEdit::returnPressed, this, &LoginDialog::onLoginClicked);
    connect(passwordEdit, &QLineEdit::returnPressed, this, &LoginDialog::onLoginClicked);
}

void LoginDialog::applyStyles() {
    // Styles are applied via the global stylesheet
}

void LoginDialog::onLoginClicked() {
    QString email = emailEdit->text().trimmed();
    QString password = passwordEdit->text();
    
    if (email.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "Input Error", "Please enter both email and password.");
        return;
    }
    
    LMSDatabase* db = LMSDatabase::getInstance();
    
    // Check admins
    Admin* admin = db->findAdminByEmail(email.toStdString());
    if (admin && admin->getPassword() == password.toStdString()) {
        loggedInUser = admin;
        emit loginSuccessful(loggedInUser);
        accept();
        return;
    }
    
    // Check students
    Student* student = db->findStudentByEmail(email.toStdString());
    if (student && student->getPassword() == password.toStdString()) {
        loggedInUser = student;
        emit loginSuccessful(loggedInUser);
        accept();
        return;
    }
    
    // Check teachers
    Teacher* teacher = db->findTeacherByEmail(email.toStdString());
    if (teacher && teacher->getPassword() == password.toStdString()) {
        loggedInUser = teacher;
        emit loginSuccessful(loggedInUser);
        accept();
        return;
    }
    
    QMessageBox::critical(this, "Login Failed", "Invalid email or password!");
    passwordEdit->clear();
    passwordEdit->setFocus();
}

void LoginDialog::onCreateAccountClicked() {
    QMessageBox::information(this, "Create Account", 
        "Account creation feature coming soon!\n\n"
        "For now, please use the default accounts:\n"
        "Admin: admin@uni.edu / admin123\n"
        "Student: john@uni.edu / student123\n"
        "Teacher: smith@uni.edu / teacher123");
}

User* LoginDialog::getLoggedInUser() const {
    return loggedInUser;
}
