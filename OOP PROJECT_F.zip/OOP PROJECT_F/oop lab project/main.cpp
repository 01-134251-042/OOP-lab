﻿#include <QApplication>
#include <QFile>
#include <QMessageBox>
#include "mainwindow.h"
#include "lmsdatabase.h"

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    
    // Set application metadata
    app.setApplicationName("Learning Management System");
    app.setApplicationVersion("1.0");
    app.setOrganizationName("University");
    
    // Load stylesheet
    QFile styleFile("styles.qss");
    if (styleFile.open(QFile::ReadOnly)) {
        QString styleSheet = QLatin1String(styleFile.readAll());
        app.setStyleSheet(styleSheet);
        styleFile.close();
    } else {
        qWarning("Could not load styles.qss - using default styling");
    }
    
    // Initialize database and load existing data
    LMSDatabase* db = LMSDatabase::getInstance();
    db->loadAllData();
    
    // Create default accounts ONLY if database is completely empty
    if (db->getAdmins().empty() && db->getStudents().empty() && db->getTeachers().empty()) {
        qDebug("No users found - creating default accounts...");
        
        Admin* defaultAdmin = new Admin(1, "Admin User", "admin@uni.edu", "admin123", "SuperAdmin");
        Student* defaultStudent = new Student(2, "John Doe", "john@uni.edu", "student123", 1001, 3.5);
        Teacher* defaultTeacher = new Teacher(3, "Dr Smith", "smith@uni.edu", "teacher123", "Computer Science", "PhD");
        
        db->addAdmin(defaultAdmin);
        db->addStudent(defaultStudent);
        db->addTeacher(defaultTeacher);
        
        qDebug("Default accounts created:");
        qDebug("  Admin: admin@uni.edu / admin123");
        qDebug("  Student: john@uni.edu / student123");
        qDebug("  Teacher: smith@uni.edu / teacher123");
    } else {
        qDebug("Loaded %d admin(s), %d student(s), %d teacher(s)",
               (int)db->getAdmins().size(),
               (int)db->getStudents().size(),
               (int)db->getTeachers().size());
    }
    
    // Create and show main window
    MainWindow mainWindow;
    mainWindow.show();
    
    // Run application
    int result = app.exec();
    
    // Save all data before exit
    db->saveAllData();
    
    return result;
}