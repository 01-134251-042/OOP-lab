﻿#include "Admin.h"
#include "Student.h"
#include "Teacher.h"
#include "lmsdatabase.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <algorithm>

Admin::Admin(int id, string name, string email, string password, string adminLevel)
    : User(id, name, email, password, "Admin"), adminLevel(adminLevel) {

    if (adminLevel.empty()) throw invalid_argument("ERROR: Admin level cannot be empty");
}

Admin::~Admin() {
    
    students.clear();
    teachers.clear();
    courses.clear();
}

string Admin::getAdminLevel() const { return adminLevel; }
vector<Student*> Admin::getStudents() const { return students; }
vector<Teacher*> Admin::getTeachers() const { return teachers; }
vector<Course*> Admin::getCourses() const { return courses; }

void Admin::setAdminLevel(string level) {
    if (level.empty()) throw invalid_argument("ERROR: Admin level cannot be empty");
    adminLevel = level;
}

// Functionality 1: Add Student
bool Admin::addStudent(Student* student) {
    if (student == nullptr) throw invalid_argument("ERROR: Student cannot be null");

    // Check if already exists
    for (auto& s : students) {
        if (s->getId() == student->getId()) {
            throw runtime_error("ERROR: Student with ID " + to_string(student->getId()) + " already exists");
        }
    }

    students.push_back(student);

    cout << "\nStudent added successfully!\n";
    cout << "Name: " << student->getName() << "\n";
    cout << "Email: " << student->getEmail() << "\n";
    return true;
}

// Functionality 2: Add Teacher
bool Admin::addTeacher(Teacher* teacher) {
    if (teacher == nullptr) throw invalid_argument("ERROR: Teacher cannot be null");

    // Check if already exists
    for (auto& t : teachers) {
        if (t->getId() == teacher->getId()) {
            throw runtime_error("ERROR: Teacher with ID " + to_string(teacher->getId()) + " already exists");
        }
    }

    teachers.push_back(teacher);

    cout << "\nTeacher added successfully!\n";
    cout << "Name: " << teacher->getName() << "\n";
    cout << "Email: " << teacher->getEmail() << "\n";
    return true;
}

// Functionality 3: Remove User
bool Admin::removeStudent(int studentId) {
    auto it = find_if(students.begin(), students.end(),
        [studentId](Student* s) { return s->getId() == studentId; });

    if (it != students.end()) {
        cout << "\nStudent removed: " << (*it)->getName() << "\n";
        students.erase(it);
        return true;
    }

    throw runtime_error("ERROR: Student with ID " + to_string(studentId) + " not found");
}

bool Admin::removeTeacher(int teacherId) {
    auto it = find_if(teachers.begin(), teachers.end(),
        [teacherId](Teacher* t) { return t->getId() == teacherId; });

    if (it != teachers.end()) {
        cout << "\nTeacher removed: " << (*it)->getName() << "\n";
        teachers.erase(it);
        return true;
    }

    throw runtime_error("ERROR: Teacher with ID " + to_string(teacherId) + " not found");
}

// Functionality 4: View All Users - UPDATED TO USE LMSDATABASE
void Admin::viewAllUsers() const {
    LMSDatabase* db = LMSDatabase::getInstance();
    
    auto& students = db->getStudents();
    auto& teachers = db->getTeachers();

    cout << "\n*****************************************";
    cout << "\n       --- ALL USERS IN SYSTEM ---       ";
    cout << "\n*****************************************";

    cout << "\n--- STUDENTS (" << students.size() << ") ---\n";
    if (students.empty()) {
        cout << "No students registered.\n";
    }
    else {
        for (size_t i = 0; i < students.size(); i++) {
            cout << (i + 1) << ". ID:" << students[i]->getId()
                << " | " << students[i]->getName()
                << " | " << students[i]->getEmail()
                << " | Roll: " << students[i]->getRollNumber() << "\n";
        }
    }

    cout << "\n--- TEACHERS (" << teachers.size() << ") ---\n";
    if (teachers.empty()) {
        cout << "No teachers registered.\n";
    }
    else {
        for (size_t i = 0; i < teachers.size(); i++) {
            cout << (i + 1) << ". ID:" << teachers[i]->getId()
                << " | " << teachers[i]->getName()
                << " | " << teachers[i]->getEmail()
                << " | " << teachers[i]->getDepartment() << "\n";
        }
    }
}

// Functionality 5: System Statistics - UPDATED TO USE LMSDATABASE
void Admin::displaySystemStatistics() const {
    LMSDatabase* db = LMSDatabase::getInstance();
    
    auto& students = db->getStudents();
    auto& teachers = db->getTeachers();
    auto& courses = db->getCourses();
    auto& admins = db->getAdmins();

    cout << "\n***********************************";
    cout << "\n     --- SYSTEM STATISTICS ---     ";
    cout << "\n***********************************" << endl;
    cout << "Total Admins: " << admins.size() << "\n";
    cout << "Total Students: " << students.size() << "\n";
    cout << "Total Teachers: " << teachers.size() << "\n";
    cout << "Total Courses: " << courses.size() << "\n";
    cout << "Total Users: " << (admins.size() + students.size() + teachers.size()) << "\n";
}

void Admin::login() {
    cout << "\n***************************************\n";
    cout << "\n         --- ADMIN LOGIN ---           \n";
    cout << "\n   Logged in: " << name << "\n";
    cout << "\n  Level: " << adminLevel << "\n";
    cout << "\n***************************************";
}

void Admin::displayDashboard() {
    LMSDatabase* db = LMSDatabase::getInstance();
    
    auto& students = db->getStudents();
    auto& teachers = db->getTeachers();

    cout << "\n***********************************";
    cout << "\n      --- ADMIN DASHBOARD ---      ";
    cout << "\n***********************************";
    cout << "Name: " << name << "\n";
    cout << "Email: " << email << "\n";
    cout << "Level: " << adminLevel << "\n";
    cout << "Students: " << students.size() << "\n";
    cout << "Teachers: " << teachers.size() << "\n";
}

void Admin::displayMenu() {
    cout << "\n=== ADMIN MENU ===\n";
    cout << "1. View Dashboard\n";
    cout << "2. Add Student\n";
    cout << "3. Add Teacher\n";
    cout << "4. View All Users\n";
    cout << "5. Remove Student\n";
    cout << "6. Remove Teacher\n";
    cout << "7. System Statistics\n";
    cout << "8. Logout\n";
    cout << "Enter choice: ";
}

/*
string Admin::toString() const {
    stringstream ss;
    ss << id << "|" << name << "|" << email << "|" << password
        << "|" << userType << "|" << adminLevel;
    return ss.str();
}
*/

Admin* Admin::parseAdmin(const std::string& line) {
    std::stringstream ss(line);
    std::string token;
    int id;
    std::string name, email, password, userType, adminLevel;

    try {
        // Use getline consistently with '|' delimiter
        getline(ss, token, '|'); id = std::stoi(token);
        getline(ss, name, '|');
        getline(ss, email, '|');
        getline(ss, password, '|');
        getline(ss, userType, '|');
        getline(ss, adminLevel, '|');  // trailing '|' is okay

        return new Admin(id, name, email, password, adminLevel);
    }
    catch (...) {
        return nullptr;
    }
}


string Admin::toString() const {
    // Format: id|name|email|password|Admin|adminLevel|
    return to_string(getId()) + "|" + getName() + "|" + getEmail() + "|" + getPassword() + "|Admin|" + adminLevel + "|";
}