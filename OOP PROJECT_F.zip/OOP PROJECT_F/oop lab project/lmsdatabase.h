#ifndef LMSDATABASE_H
#define LMSDATABASE_H

#include <vector>
#include <string>
#include "admin.h"
#include "student.h"
#include "teacher.h"
#include "course.h"
#include "assignment.h"

using namespace std;

/**
 * @brief Singleton class for managing all database operations
 * Handles file I/O for users, courses, and assignments
 */
class LMSDatabase {
private:
    static LMSDatabase* instance;
    
    // Data storage
    vector<Admin*> admins;
    vector<Student*> students;
    vector<Teacher*> teachers;
    vector<Course*> courses;
    vector<Assignment*> assignments;
    
    // Private constructor for singleton
    LMSDatabase();
    
public:
    // Singleton instance getter
    static LMSDatabase* getInstance();
    
    // Destructor
    ~LMSDatabase();
    
    // Load operations
    void loadAllData();
    void loadAdmins();
    void loadStudents();
    void loadTeachers();
    void loadCourses();
    void loadAssignments();
    void loadEnrollments();
    
    // Save operations
    void saveAllData();
    void saveAdmins();
    void saveStudents();
    void saveTeachers();
    void saveCourses();
    void saveAssignments();
    void saveEnrollments();
    
    // Getters
    vector<Admin*>& getAdmins();
    vector<Student*>& getStudents();
    vector<Teacher*>& getTeachers();
    vector<Course*>& getCourses();
    vector<Assignment*>& getAssignments();
    
    // User management
    Admin* findAdminByEmail(const string& email);
    Student* findStudentByEmail(const string& email);
    Teacher* findTeacherByEmail(const string& email);
    
    Admin* findAdminById(int id);
    Student* findStudentById(int id);
    Teacher* findTeacherById(int id);
    Course* findCourseById(int id);
    Assignment* findAssignmentById(int id);
    
    // Add operations
    bool addAdmin(Admin* admin);
    bool addStudent(Student* student);
    bool addTeacher(Teacher* teacher);
    bool addCourse(Course* course);
    bool addAssignment(Assignment* assignment);
    
    // Remove operations
    bool removeStudent(int id);
    bool removeTeacher(int id);
    bool removeCourse(int id);
    
    // Validation
    bool isIdUnique(int id);
    bool isEmailUnique(const string& email);
    int generateUniqueId();
    
    // Cleanup
    void cleanup();
};

#endif // LMSDATABASE_H
