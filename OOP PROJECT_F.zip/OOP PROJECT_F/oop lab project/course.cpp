#include "Course.h"
#include "Student.h"
#include "Teacher.h"
#include "Assignment.h"
#include <fstream>
#include <sstream>
#include <algorithm>

Course::Course(int id, string title, int capacity, Teacher* teacher)
    : courseId(id), courseTitle(title), capacity(capacity), instructor(teacher) {

    if (id < 0) throw invalid_argument("ERROR: Course ID cannot be negative");
    if (title.empty()) throw invalid_argument("ERROR: Course title cannot be empty");
    if (capacity < 1) throw invalid_argument("ERROR: Capacity must be at least 1");
}

Course::~Course() {
    assignments.clear();
    enrolledStudents.clear();
}

int Course::getCourseId() const { return courseId; }
string Course::getCourseTitle() const { return courseTitle; }
int Course::getCapacity() const { return capacity; }
Teacher* Course::getInstructor() const { return instructor; }
vector<Assignment*> Course::getAssignments() const { return assignments; }
vector<Student*> Course::getEnrolledStudents() const { return enrolledStudents; }

void Course::setCourseTitle(string title) {
    if (title.empty()) throw invalid_argument("ERROR: Course title cannot be empty");
    courseTitle = title;
}

void Course::setCapacity(int cap) {
    if (cap < 1) throw invalid_argument("ERROR: Capacity must be at least 1");
    capacity = cap;
}

bool Course::enrollStudent(Student* student) {
    if (student == nullptr) throw invalid_argument("ERROR: Student cannot be null");

    if (enrolledStudents.size() >= (size_t)capacity) {
        throw runtime_error("ERROR: Course is full");
    }

    auto it = find(enrolledStudents.begin(), enrolledStudents.end(), student);
    if (it != enrolledStudents.end()) {
        throw runtime_error("ERROR: Student already enrolled");
    }

    enrolledStudents.push_back(student);
    return true;
}

bool Course::removeStudent(int studentId) {
    auto it = find_if(enrolledStudents.begin(), enrolledStudents.end(),
        [studentId](Student* s) { return s->getId() == studentId; });

    if (it != enrolledStudents.end()) {
        enrolledStudents.erase(it);
        return true;
    }
    return false;
}

void Course::addAssignment(Assignment* assignment) {
    if (assignment == nullptr) throw invalid_argument("ERROR: Assignment cannot be null");
    assignments.push_back(assignment);
}

void Course::displayCourseInfo() const {
    cout << "\n*******************************************\n";
    cout << "\n --- COURSE INFORMATION ---            \n";
    cout << "\n Course ID: " << courseId << "\n";
    cout << "\n Title: " << courseTitle << "\n";
    cout << "\n Capacity: " << capacity << "\n";
    cout << "\n Enrolled: " << enrolledStudents.size() << "\n";
    cout << "\n Assignments: " << assignments.size() << "\n";
    cout << "\n*******************************************";
}

void Course::listEnrolledStudents() const {
    cout << "\n=== ENROLLED STUDENTS ===\n";
    if (enrolledStudents.empty()) {
        cout << "No students enrolled.\n";
        return;
    }
    for (size_t i = 0; i < enrolledStudents.size(); i++) {
        cout << (i + 1) << ". " << enrolledStudents[i]->getName() << "\n";
    }
}

string Course::toString() const {
    stringstream ss;
    ss << courseId << "|" << courseTitle << "|" << capacity;
    return ss.str();
}

Course* Course::parseCourse(string line) {
    stringstream ss(line);
    int id, capacity;
    string title;
    char delim;

    try {
        ss >> id >> delim;
        getline(ss, title, '|');
        ss >> capacity;
        return new Course(id, title, capacity);
    }
    catch (...) {
        return nullptr;
    }
}