#include "User.h"
#include <regex>
#include <sstream>

// Constructor
User::User(int id, string name, string email, string password, string userType)
    : id(id), name(name), email(email), password(password), userType(userType) {

    if (!validateEmail(email) && !email.empty()) {
        throw invalid_argument("ERROR: Invalid email format");
    }
    if (!validatePassword(password) && !password.empty()) {
        throw invalid_argument("ERROR: Password must be at least 6 characters");
    }
    if (!validateName(name) && !name.empty()) {
        throw invalid_argument("ERROR: Name can only contain letters and spaces");
    }
}

User::~User() {}

// Getters
int User::getId() const { return id; }
string User::getName() const { return name; }
string User::getEmail() const { return email; }
string User::getPassword() const { return password; }
string User::getUserType() const { return userType; }

// Setters
void User::setName(string n) {
    if (!validateName(n)) throw invalid_argument("ERROR: Invalid name");
    name = n;
}

void User::setEmail(string e) {
    if (!validateEmail(e)) throw invalid_argument("ERROR: Invalid email");
    email = e;
}

void User::setPassword(string p) {
    if (!validatePassword(p)) throw invalid_argument("ERROR: Password too short");
    password = p;
}

// Email validation - Regex pattern
bool User::validateEmail(string email) const {
    if (email.empty()) return true;
    regex emailPattern("^[a-zA-Z0-9._%-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$");
    return regex_match(email, emailPattern);
}

// Password validation
bool User::validatePassword(string password) const {
    return password.length() >= 6;
}

// Name validation
bool User::validateName(string name) const { 
    if (name.empty()) return true;
    for (char c : name) {
        if (!isalpha(c) && c != ' ') return false;
    }
    return true;
}

// String conversion for file storage
string User::toString() const {
    stringstream ss;
    ss << id << "|" << name << "|" << email << "|" << password << "|" << userType;
    return ss.str();
}

User* User::parseUser(string line) {
    return nullptr; // Implemented in derived classes
}