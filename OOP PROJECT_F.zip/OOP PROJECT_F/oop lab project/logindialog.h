#ifndef LOGINDIALOG_H
#define LOGINDIALOG_H

#include <QDialog>
#include <QLineEdit>
#include <QPushButton>
#include <QComboBox>
#include "user.h"

class LoginDialog : public QDialog {
    Q_OBJECT

public:
    explicit LoginDialog(QWidget *parent = nullptr);
    ~LoginDialog();
    
    User* getLoggedInUser() const;

signals:
    void loginSuccessful(User* user);

private slots:
    void onLoginClicked();
    void onCreateAccountClicked();

private:
    void setupUI();
    void applyStyles();
    
    QLineEdit* emailEdit;
    QLineEdit* passwordEdit;
    QPushButton* loginButton;
    QPushButton* createAccountButton;
    
    User* loggedInUser;
};

#endif // LOGINDIALOG_H
