#ifndef ADMINDASHBOARD_H
#define ADMINDASHBOARD_H

#include <QWidget>
#include <QPushButton>
#include <QTableWidget>
#include <QLabel>
#include "admin.h"

class AdminDashboard : public QWidget {
    Q_OBJECT

public:
    explicit AdminDashboard(Admin* admin, QWidget *parent = nullptr);
    ~AdminDashboard();
    
    void refreshData();

signals:
    void logoutRequested();

private slots:
    void onAddStudentClicked();
    void onAddTeacherClicked();
    void onRemoveUserClicked();
    void onViewStatisticsClicked();
    void onLogoutClicked();

private:
    void setupUI();
    void applyStyles();
    void updateStatistics();
    
    Admin* currentAdmin;
    
    QLabel* welcomeLabel;
    QLabel* statsLabel;
    QPushButton* addStudentBtn;
    QPushButton* addTeacherBtn;
    QPushButton* removeUserBtn;
    QPushButton* viewStatsBtn;
    QPushButton* logoutBtn;
    QTableWidget* usersTable;
};

#endif // ADMINDASHBOARD_H
