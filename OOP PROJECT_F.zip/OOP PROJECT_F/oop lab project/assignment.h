#ifndef ASSIGNMENT_H
#define ASSIGNMENT_H

#include <string>
#include <vector>
#include <iostream>

using namespace std;

class Assignment {
private:
    int assignmentId;
    string title;
    string deadline;
    int courseId;
    float totalMarks;

public:
    Assignment(int id = 0, string title = "", string deadline = "", int courseId = 0, float marks = 100);
    virtual ~Assignment();

    int getId() const;
    string getTitle() const;
    string getDeadline() const;
    int getCourseId() const;
    float getTotalMarks() const;

    void setTitle(string t);
    void setDeadline(string d);
    void setTotalMarks(float m);

    void displayAssignmentInfo() const;

    string toString() const;
    static Assignment* parseAssignment(string line);
};

#endif // ASSIGNMENT_H#pragma once
