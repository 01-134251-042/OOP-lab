#include "admindashboard.h"
#include "lmsdatabase.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QHeaderView>
#include <QMessageBox>
#include <QInputDialog>
#include <QGroupBox>
#include <QDebug>

AdminDashboard::AdminDashboard(Admin* admin, QWidget *parent)
    : QWidget(parent), currentAdmin(admin)
{
    setupUI();
    applyStyles();
    refreshData();
}

AdminDashboard::~AdminDashboard() {
}

void AdminDashboard::setupUI() {
    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(20);
    mainLayout->setContentsMargins(30, 30, 30, 30);
    
    // Welcome header
    welcomeLabel = new QLabel(QString("Welcome, %1").arg(QString::fromStdString(currentAdmin->getName())), this);
    welcomeLabel->setObjectName("welcomeLabel");
    mainLayout->addWidget(welcomeLabel);
    
    // Statistics label
    statsLabel = new QLabel(this);
    statsLabel->setObjectName("statsLabel");
    mainLayout->addWidget(statsLabel);
    
    // Action buttons
    QGroupBox* actionsGroup = new QGroupBox("Admin Actions", this);
    QGridLayout* buttonGrid = new QGridLayout(actionsGroup);
    buttonGrid->setSpacing(15);
    
    addStudentBtn = new QPushButton("➕ Add Student", this);
    addStudentBtn->setObjectName("addStudentBtn");
    addStudentBtn->setToolTip("Add a new student to the system");
    buttonGrid->addWidget(addStudentBtn, 0, 0);
    
    addTeacherBtn = new QPushButton("➕ Add Teacher", this);
    addTeacherBtn->setObjectName("addStudentBtn");
    addTeacherBtn->setToolTip("Add a new teacher to the system");
    buttonGrid->addWidget(addTeacherBtn, 0, 1);
    
    removeUserBtn = new QPushButton("🗑️ Remove User", this);
    removeUserBtn->setObjectName("removeUserBtn");
    removeUserBtn->setToolTip("Remove a student or teacher");
    buttonGrid->addWidget(removeUserBtn, 1, 0);
    
    viewStatsBtn = new QPushButton("📊 View Statistics", this);
    viewStatsBtn->setObjectName("viewStatsBtn");
    viewStatsBtn->setToolTip("View detailed system statistics");
    buttonGrid->addWidget(viewStatsBtn, 1, 1);
    
    logoutBtn = new QPushButton("🚪 Logout", this);
    logoutBtn->setObjectName("logoutBtn");
    logoutBtn->setToolTip("Logout from admin panel");
    buttonGrid->addWidget(logoutBtn, 2, 0, 1, 2);
    
    mainLayout->addWidget(actionsGroup);
    
    // Users table
    QGroupBox* usersGroup = new QGroupBox("All Users", this);
    QVBoxLayout* tableLayout = new QVBoxLayout(usersGroup);
    
    usersTable = new QTableWidget(this);
    usersTable->setColumnCount(5);
    usersTable->setHorizontalHeaderLabels({"ID", "Name", "Email", "Type", "Details"});
    usersTable->horizontalHeader()->setStretchLastSection(true);
    usersTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    usersTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    usersTable->setAlternatingRowColors(true);
    tableLayout->addWidget(usersTable);
    
    mainLayout->addWidget(usersGroup);
    
    // Connect signals
    connect(addStudentBtn, &QPushButton::clicked, this, &AdminDashboard::onAddStudentClicked);
    connect(addTeacherBtn, &QPushButton::clicked, this, &AdminDashboard::onAddTeacherClicked);
    connect(removeUserBtn, &QPushButton::clicked, this, &AdminDashboard::onRemoveUserClicked);
    connect(viewStatsBtn, &QPushButton::clicked, this, &AdminDashboard::onViewStatisticsClicked);
    connect(logoutBtn, &QPushButton::clicked, this, &AdminDashboard::onLogoutClicked);
}

void AdminDashboard::applyStyles() {
    // Styles applied via global stylesheet
}

void AdminDashboard::refreshData() {
    updateStatistics();
    
    // Populate users table
    usersTable->setRowCount(0);
    LMSDatabase* db = LMSDatabase::getInstance();
    
    int row = 0;
    
    // Add admins
    for (Admin* admin : db->getAdmins()) {
        if (admin) {
            usersTable->insertRow(row);
            usersTable->setItem(row, 0, new QTableWidgetItem(QString::number(admin->getId())));
            usersTable->setItem(row, 1, new QTableWidgetItem(QString::fromStdString(admin->getName())));
            usersTable->setItem(row, 2, new QTableWidgetItem(QString::fromStdString(admin->getEmail())));
            usersTable->setItem(row, 3, new QTableWidgetItem("Admin"));
            usersTable->setItem(row, 4, new QTableWidgetItem(QString::fromStdString(admin->getAdminLevel())));
            row++;
        }
    }
    
    // Add students
    for (Student* student : db->getStudents()) {
        if (student) {
            usersTable->insertRow(row);
            usersTable->setItem(row, 0, new QTableWidgetItem(QString::number(student->getId())));
            usersTable->setItem(row, 1, new QTableWidgetItem(QString::fromStdString(student->getName())));
            usersTable->setItem(row, 2, new QTableWidgetItem(QString::fromStdString(student->getEmail())));
            usersTable->setItem(row, 3, new QTableWidgetItem("Student"));
            usersTable->setItem(row, 4, new QTableWidgetItem(QString("Roll: %1, GPA: %2")
                .arg(student->getRollNumber()).arg(student->getGPA(), 0, 'f', 2)));
            row++;
        }
    }
    
    // Add teachers
    for (Teacher* teacher : db->getTeachers()) {
        if (teacher) {
            usersTable->insertRow(row);
            usersTable->setItem(row, 0, new QTableWidgetItem(QString::number(teacher->getId())));
            usersTable->setItem(row, 1, new QTableWidgetItem(QString::fromStdString(teacher->getName())));
            usersTable->setItem(row, 2, new QTableWidgetItem(QString::fromStdString(teacher->getEmail())));
            usersTable->setItem(row, 3, new QTableWidgetItem("Teacher"));
            usersTable->setItem(row, 4, new QTableWidgetItem(QString::fromStdString(teacher->getDepartment())));
            row++;
        }
    }
    
    usersTable->resizeColumnsToContents();
}

void AdminDashboard::updateStatistics() {
    LMSDatabase* db = LMSDatabase::getInstance();
    int adminCount = db->getAdmins().size();
    int studentCount = db->getStudents().size();
    int teacherCount = db->getTeachers().size();
    int totalUsers = adminCount + studentCount + teacherCount;
    
    statsLabel->setText(QString(
        "📈 System Statistics: %1 Total Users | %2 Admins | %3 Students | %4 Teachers")
        .arg(totalUsers).arg(adminCount).arg(studentCount).arg(teacherCount));
}

void AdminDashboard::onAddStudentClicked() {
    try {
        bool ok;
        QString name = QInputDialog::getText(this, "Add Student", "Student Name:", QLineEdit::Normal, "", &ok);
        if (!ok || name.isEmpty()) return;
        
        QString email = QInputDialog::getText(this, "Add Student", "Email:", QLineEdit::Normal, "", &ok);
        if (!ok || email.isEmpty()) return;
        
        QString password = QInputDialog::getText(this, "Add Student", "Password:", QLineEdit::Password, "", &ok);
        if (!ok || password.isEmpty()) return;
        
        int rollNumber = QInputDialog::getInt(this, "Add Student", "Roll Number:", 1000, 1, 999999, 1, &ok);
        if (!ok) return;
        
        double gpa = QInputDialog::getDouble(this, "Add Student", "GPA:", 3.0, 0.0, 4.0, 2, &ok);
        if (!ok) return;
        
        qDebug() << "[DEBUG] Creating student with name:" << name;
        
        LMSDatabase* db = LMSDatabase::getInstance();
        int id = db->generateUniqueId();
        
        qDebug() << "[DEBUG] Generated ID:" << id;
        
        Student* newStudent = new Student(id, name.toStdString(), email.toStdString(), 
                                         password.toStdString(), rollNumber, gpa);
        
        qDebug() << "[DEBUG] Student object created, attempting to add to database";
        
        if (db->addStudent(newStudent)) {
            qDebug() << "[DEBUG] Student added successfully to database";
            QMessageBox::information(this, "Success", 
                QString("Student added successfully!\nID: %1\nName: %2\nEmail: %3")
                .arg(id).arg(name).arg(email));
            refreshData();
        } else {
            qDebug() << "[ERROR] Failed to add student to database";
            delete newStudent;
            QMessageBox::critical(this, "Error", "Failed to add student. Email may already exist.");
        }
    }
    catch (const std::exception& e) {
        qDebug() << "[EXCEPTION] Error in onAddStudentClicked:" << e.what();
        QMessageBox::critical(this, "Error", QString("Exception occurred: %1").arg(e.what()));
    }
    catch (...) {
        qDebug() << "[EXCEPTION] Unknown error in onAddStudentClicked";
        QMessageBox::critical(this, "Error", "Unknown error occurred while adding student");
    }
}

void AdminDashboard::onAddTeacherClicked() {
    try {
        bool ok;
        QString name = QInputDialog::getText(this, "Add Teacher", "Teacher Name:", QLineEdit::Normal, "", &ok);
        if (!ok || name.isEmpty()) return;
        
        QString email = QInputDialog::getText(this, "Add Teacher", "Email:", QLineEdit::Normal, "", &ok);
        if (!ok || email.isEmpty()) return;
        
        QString password = QInputDialog::getText(this, "Add Teacher", "Password:", QLineEdit::Password, "", &ok);
        if (!ok || password.isEmpty()) return;
        
        QString department = QInputDialog::getText(this, "Add Teacher", "Department:", QLineEdit::Normal, "", &ok);
        if (!ok || department.isEmpty()) return;
        
        QString qualification = QInputDialog::getText(this, "Add Teacher", "Qualification:", QLineEdit::Normal, "", &ok);
        if (!ok || qualification.isEmpty()) return;
        
        qDebug() << "[DEBUG] Creating teacher with name:" << name;
        
        LMSDatabase* db = LMSDatabase::getInstance();
        int id = db->generateUniqueId();
        
        qDebug() << "[DEBUG] Generated ID:" << id;
        
        Teacher* newTeacher = new Teacher(id, name.toStdString(), email.toStdString(), 
                                         password.toStdString(), department.toStdString(), 
                                         qualification.toStdString());
        
        qDebug() << "[DEBUG] Teacher object created, attempting to add to database";
        
        if (db->addTeacher(newTeacher)) {
            qDebug() << "[DEBUG] Teacher added successfully to database";
            QMessageBox::information(this, "Success", 
                QString("Teacher added successfully!\nID: %1\nName: %2\nEmail: %3")
                .arg(id).arg(name).arg(email));
            refreshData();
        } else {
            qDebug() << "[ERROR] Failed to add teacher to database";
            delete newTeacher;
            QMessageBox::critical(this, "Error", "Failed to add teacher. Email may already exist.");
        }
    }
    catch (const std::exception& e) {
        qDebug() << "[EXCEPTION] Error in onAddTeacherClicked:" << e.what();
        QMessageBox::critical(this, "Error", QString("Exception occurred: %1").arg(e.what()));
    }
    catch (...) {
        qDebug() << "[EXCEPTION] Unknown error in onAddTeacherClicked";
        QMessageBox::critical(this, "Error", "Unknown error occurred while adding teacher");
    }
}

void AdminDashboard::onRemoveUserClicked() {
    bool ok;
    int userId = QInputDialog::getInt(this, "Remove User", "Enter User ID to remove:", 0, 0, 999999, 1, &ok);
    if (!ok) return;
    
    LMSDatabase* db = LMSDatabase::getInstance();
    
    if (db->removeStudent(userId) || db->removeTeacher(userId)) {
        QMessageBox::information(this, "Success", "User removed successfully!");
        refreshData();
    } else {
        QMessageBox::warning(this, "Not Found", "User not found or cannot be removed.");
    }
}

void AdminDashboard::onViewStatisticsClicked() {
    LMSDatabase* db = LMSDatabase::getInstance();
    
    QString stats = QString(
        "📊 Detailed System Statistics\n\n"
        "Total Admins: %1\n"
        "Total Students: %2\n"
        "Total Teachers: %3\n"
        "Total Users: %4\n\n"
        "System Status: Operational ✅"
    ).arg(db->getAdmins().size())
     .arg(db->getStudents().size())
     .arg(db->getTeachers().size())
     .arg(db->getAdmins().size() + db->getStudents().size() + db->getTeachers().size());
    
    QMessageBox::information(this, "System Statistics", stats);
}

void AdminDashboard::onLogoutClicked() {
    auto reply = QMessageBox::question(this, "Logout", "Are you sure you want to logout?",
                                      QMessageBox::Yes | QMessageBox::No);
    if (reply == QMessageBox::Yes) {
        emit logoutRequested();
    }
}
