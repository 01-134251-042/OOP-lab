#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include "user.h"
#include "admin.h"
#include "student.h"
#include "teacher.h"

class AdminDashboard;
class StudentDashboard;
class TeacherDashboard;

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onLoginSuccess(User* user);
    void onLogout();

private:
    void setupUI();
    void showLoginDialog();
    
    QStackedWidget* stackedWidget;
    AdminDashboard* adminDashboard;
    StudentDashboard* studentDashboard;
    TeacherDashboard* teacherDashboard;
    
    User* currentUser;
};

#endif // MAINWINDOW_H
