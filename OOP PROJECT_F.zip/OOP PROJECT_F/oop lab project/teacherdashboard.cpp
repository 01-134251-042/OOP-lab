#include "teacherdashboard.h"
#include "lmsdatabase.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QHeaderView>
#include <QMessageBox>
#include <QInputDialog>
#include <QGroupBox>

TeacherDashboard::TeacherDashboard(Teacher* teacher, QWidget *parent)
    : QWidget(parent), currentTeacher(teacher)
{
    setupUI();
    applyStyles();
    refreshData();
}

TeacherDashboard::~TeacherDashboard() {
}

void TeacherDashboard::setupUI() {
    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(20);
    mainLayout->setContentsMargins(30, 30, 30, 30);
    
    // Welcome header
    welcomeLabel = new QLabel(QString("Welcome, %1").arg(QString::fromStdString(currentTeacher->getName())), this);
    welcomeLabel->setObjectName("welcomeLabel");
    mainLayout->addWidget(welcomeLabel);
    
    // Department label
    departmentLabel = new QLabel(QString("🏛️ Department: %1 | Qualification: %2")
        .arg(QString::fromStdString(currentTeacher->getDepartment()))
        .arg(QString::fromStdString(currentTeacher->getQualification())), this);
    departmentLabel->setObjectName("departmentLabel");
    mainLayout->addWidget(departmentLabel);
    
    // Action buttons
    QGroupBox* actionsGroup = new QGroupBox("Teacher Actions", this);
    QGridLayout* buttonGrid = new QGridLayout(actionsGroup);
    buttonGrid->setSpacing(15);
    
    createCourseBtn = new QPushButton("➕ Create Course", this);
    createCourseBtn->setObjectName("createCourseBtn");
    createCourseBtn->setToolTip("Create a new course");
    buttonGrid->addWidget(createCourseBtn, 0, 0);
    
    createAssignmentBtn = new QPushButton("📝 Create Assignment", this);
    createAssignmentBtn->setToolTip("Create a new assignment");
    buttonGrid->addWidget(createAssignmentBtn, 0, 1);
    
    uploadNotesBtn = new QPushButton("📤 Upload Notes", this);
    uploadNotesBtn->setToolTip("Upload course notes");
    buttonGrid->addWidget(uploadNotesBtn, 1, 0);
    
    giveMarksBtn = new QPushButton("✍️ Give Marks", this);
    giveMarksBtn->setToolTip("Assign marks to students");
    buttonGrid->addWidget(giveMarksBtn, 1, 1);
    
    viewStudentsBtn = new QPushButton("👥 View Students", this);
    viewStudentsBtn->setObjectName("viewStatsBtn");
    viewStudentsBtn->setToolTip("View students in your courses");
    buttonGrid->addWidget(viewStudentsBtn, 2, 0);
    
    logoutBtn = new QPushButton("🚪 Logout", this);
    logoutBtn->setObjectName("logoutBtn");
    logoutBtn->setToolTip("Logout from teacher panel");
    buttonGrid->addWidget(logoutBtn, 2, 1);
    
    mainLayout->addWidget(actionsGroup);
    
    // Taught courses list
    QGroupBox* coursesGroup = new QGroupBox("My Courses", this);
    QVBoxLayout* coursesLayout = new QVBoxLayout(coursesGroup);
    
    coursesList = new QListWidget(this);
    coursesLayout->addWidget(coursesList);
    
    mainLayout->addWidget(coursesGroup);
    
    // Students table
    QGroupBox* studentsGroup = new QGroupBox("Students in Selected Course", this);
    QVBoxLayout* studentsLayout = new QVBoxLayout(studentsGroup);
    
    studentsTable = new QTableWidget(this);
    studentsTable->setColumnCount(4);
    studentsTable->setHorizontalHeaderLabels({"ID", "Name", "Roll Number", "GPA"});
    studentsTable->horizontalHeader()->setStretchLastSection(true);
    studentsTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    studentsTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    studentsTable->setAlternatingRowColors(true);
    studentsLayout->addWidget(studentsTable);
    
    mainLayout->addWidget(studentsGroup);
    
    // Connect signals
    connect(createCourseBtn, &QPushButton::clicked, this, &TeacherDashboard::onCreateCourseClicked);
    connect(createAssignmentBtn, &QPushButton::clicked, this, &TeacherDashboard::onCreateAssignmentClicked);
    connect(uploadNotesBtn, &QPushButton::clicked, this, &TeacherDashboard::onUploadNotesClicked);
    connect(giveMarksBtn, &QPushButton::clicked, this, &TeacherDashboard::onGiveMarksClicked);
    connect(viewStudentsBtn, &QPushButton::clicked, this, &TeacherDashboard::onViewStudentsClicked);
    connect(logoutBtn, &QPushButton::clicked, this, &TeacherDashboard::onLogoutClicked);
}

void TeacherDashboard::applyStyles() {
    // Styles applied via global stylesheet
}

void TeacherDashboard::refreshData() {
    updateCourseList();
    
    // Update students table (placeholder)
    studentsTable->setRowCount(0);
    LMSDatabase* db = LMSDatabase::getInstance();
    
    int row = 0;
    for (Student* student : db->getStudents()) {
        if (student) {
            studentsTable->insertRow(row);
            studentsTable->setItem(row, 0, new QTableWidgetItem(QString::number(student->getId())));
            studentsTable->setItem(row, 1, new QTableWidgetItem(QString::fromStdString(student->getName())));
            studentsTable->setItem(row, 2, new QTableWidgetItem(QString::number(student->getRollNumber())));
            studentsTable->setItem(row, 3, new QTableWidgetItem(QString::number(student->getGPA(), 'f', 2)));
            row++;
        }
    }
}

void TeacherDashboard::updateCourseList() {
    coursesList->clear();
    
    auto taughtCourses = currentTeacher->getTaughtCourses();
    
    if (taughtCourses.empty()) {
        coursesList->addItem("No courses created yet. Click 'Create Course' to get started!");
    } else {
        for (Course* course : taughtCourses) {
            if (course) {
                QString courseInfo = QString("📚 %1 (ID: %2)")
                    .arg(QString::fromStdString(course->getCourseTitle()))
                    .arg(course->getCourseId());
                coursesList->addItem(courseInfo);
            }
        }
    }
}

void TeacherDashboard::onCreateCourseClicked() {
    bool ok;
    int courseId = QInputDialog::getInt(this, "Create Course", "Course ID:", 100, 1, 999999, 1, &ok);
    if (!ok) return;
    
    QString courseName = QInputDialog::getText(this, "Create Course", "Course Name:", QLineEdit::Normal, "", &ok);
    if (!ok || courseName.isEmpty()) return;
    
    try {
        currentTeacher->createCourse(courseId, courseName.toStdString());
        QMessageBox::information(this, "Success", 
            QString("Course '%1' created successfully!").arg(courseName));
        refreshData();
    } catch (const std::exception& e) {
        QMessageBox::warning(this, "Error", QString("Failed to create course: %1").arg(e.what()));
    }
}

void TeacherDashboard::onCreateAssignmentClicked() {
    bool ok;
    int assignmentId = QInputDialog::getInt(this, "Create Assignment", "Assignment ID:", 1, 1, 999999, 1, &ok);
    if (!ok) return;
    
    QString title = QInputDialog::getText(this, "Create Assignment", "Assignment Title:", QLineEdit::Normal, "", &ok);
    if (!ok || title.isEmpty()) return;
    
    QString deadline = QInputDialog::getText(this, "Create Assignment", "Deadline (YYYY-MM-DD):", QLineEdit::Normal, "", &ok);
    if (!ok || deadline.isEmpty()) return;
    
    try {
        currentTeacher->createAssignment(assignmentId, title.toStdString(), deadline.toStdString());
        QMessageBox::information(this, "Success", 
            QString("Assignment '%1' created successfully!").arg(title));
    } catch (const std::exception& e) {
        QMessageBox::warning(this, "Error", QString("Failed to create assignment: %1").arg(e.what()));
    }
}

void TeacherDashboard::onUploadNotesClicked() {
    bool ok;
    int courseId = QInputDialog::getInt(this, "Upload Notes", "Course ID:", 100, 1, 999999, 1, &ok);
    if (!ok) return;
    
    QString fileName = QInputDialog::getText(this, "Upload Notes", "File Path:", QLineEdit::Normal, "", &ok);
    if (!ok || fileName.isEmpty()) return;
    
    try {
        currentTeacher->uploadNotes(courseId, fileName.toStdString());
        QMessageBox::information(this, "Success", "Notes uploaded successfully!");
    } catch (const std::exception& e) {
        QMessageBox::warning(this, "Error", QString("Failed to upload notes: %1").arg(e.what()));
    }
}

void TeacherDashboard::onGiveMarksClicked() {
    bool ok;
    int studentId = QInputDialog::getInt(this, "Give Marks", "Student ID:", 1, 1, 999999, 1, &ok);
    if (!ok) return;
    
    int assignmentId = QInputDialog::getInt(this, "Give Marks", "Assignment ID:", 1, 1, 999999, 1, &ok);
    if (!ok) return;
    
    double marks = QInputDialog::getDouble(this, "Give Marks", "Marks:", 0, 0, 100, 2, &ok);
    if (!ok) return;
    
    try {
        currentTeacher->giveMarks(studentId, assignmentId, marks);
        QMessageBox::information(this, "Success", "Marks assigned successfully!");
    } catch (const std::exception& e) {
        QMessageBox::warning(this, "Error", QString("Failed to assign marks: %1").arg(e.what()));
    }
}

void TeacherDashboard::onViewStudentsClicked() {
    bool ok;
    int courseId = QInputDialog::getInt(this, "View Students", "Enter Course ID:", 100, 1, 999999, 1, &ok);
    if (!ok) return;
    
    currentTeacher->viewCourseStudents(courseId);
    
    QMessageBox::information(this, "View Students", 
        "Student list has been displayed in the console.\n"
        "Check the table below for all students.");
}

void TeacherDashboard::onLogoutClicked() {
    auto reply = QMessageBox::question(this, "Logout", "Are you sure you want to logout?",
                                      QMessageBox::Yes | QMessageBox::No);
    if (reply == QMessageBox::Yes) {
        emit logoutRequested();
    }
}
