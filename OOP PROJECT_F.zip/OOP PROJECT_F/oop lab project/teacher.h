#ifndef TEACHER_H
#define TEACHER_H

#include "User.h"
#include <vector>

class Course;
class Assignment;

class Teacher : public User {
private:
    string department;
    string qualification;
    vector<Course*> taughtCourses;      // Composition
    vector<Assignment*> assignments;     // Composition

public:
    Teacher(int id = 0, string name = "", string email = "",
        string password = "", string department = "", string qualification = "");

    virtual ~Teacher();

    string getDepartment() const;
    string getQualification() const;
    vector<Course*> getTaughtCourses() const;

    void setDepartment(string d);
    void setQualification(string q);

    // Functionality 1: Upload Notes
    void uploadNotes(int courseId, string file);

    // Functionality 2: Create Assignment
    void createAssignment(int assignmentId, string title, string deadline);

    // Functionality 3: Give Marks
    void giveMarks(int studentId, int assignmentId, float marks);

    // Functionality 4: Create Course
    void createCourse(int courseId, string title);

    // Functionality 5: View Course Students
    void viewCourseStudents(int courseId) const;

    // Polymorphism - Override virtual functions
    virtual void login() override;
    virtual void displayDashboard() override;
    virtual void displayMenu() override;

    virtual string toString() const override;
    static Teacher* parseTeacher(string line);

};

#endif // TEACHER_H#pragma once
