#ifndef COURSE_H
#define COURSE_H

#include <string>
#include <vector>
#include <iostream>

using namespace std;

class Assignment;
class Student;
class Teacher;

class Course {
private:
    int courseId;
    string courseTitle;
    int capacity;
    Teacher* instructor;              // Composition
    vector<Assignment*> assignments;   // Composition
    vector<Student*> enrolledStudents; // Aggregation

public:
    Course(int id = 0, string title = "", int capacity = 30, Teacher* teacher = nullptr);
    virtual ~Course();

    int getCourseId() const;
    string getCourseTitle() const;
    int getCapacity() const;
    Teacher* getInstructor() const;
    vector<Assignment*> getAssignments() const;
    vector<Student*> getEnrolledStudents() const;

    void setCourseTitle(string title);
    void setCapacity(int cap);

    bool enrollStudent(Student* student);
    bool removeStudent(int studentId);
    void addAssignment(Assignment* assignment);

    void displayCourseInfo() const;
    void listEnrolledStudents() const;

    string toString() const;
    static Course* parseCourse(string line);
};

#endif // COURSE_H#pragma once
