#include "lmsdatabase.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <algorithm>
#include <filesystem>

using namespace std;

// Project directory path - change this to your actual project path
const string PROJECT_DIR = "D:/OOP PROJECT_F/oop lab project/";

// Initialize static instance
LMSDatabase* LMSDatabase::instance = nullptr;

LMSDatabase::LMSDatabase() {
    // Private constructor
}

LMSDatabase* LMSDatabase::getInstance() {
    if (instance == nullptr) {
        instance = new LMSDatabase();
    }
    return instance;
}

LMSDatabase::~LMSDatabase() {
    cleanup();
}

// ======================= LOAD OPERATIONS =======================

void LMSDatabase::loadAllData() {
    cout << "\n[INFO] Loading data from files...\n";
    loadAdmins();
    loadStudents();
    loadTeachers();
    loadCourses();
    loadEnrollments(); 
    cout << "[INFO] All data loaded successfully!\n";
}

void LMSDatabase::loadAdmins() {
    string filePath = PROJECT_DIR + "admin.txt";
    ifstream adminFile(filePath);
    if (adminFile.is_open()) {
        string line;
        int lineNum = 0;
        int adminCount = 0;

        while (getline(adminFile, line)) {
            lineNum++;
            if (line.empty()) {
                cout << "[DEBUG] Line " << lineNum << " is empty, skipping" << endl;
                continue;
            }

            cout << "[DEBUG] Processing admin line " << lineNum << ": " << line << endl;

            stringstream ss(line);
            string idStr, name, email, password, userType, adminLevel;

            try {
                // Parse format: id|name|email|password|Admin|adminLevel|
                getline(ss, idStr, '|');
                getline(ss, name, '|');
                getline(ss, email, '|');
                getline(ss, password, '|');
                getline(ss, userType, '|');
                getline(ss, adminLevel, '|');

                cout << "[DEBUG] Parsed - ID:" << idStr << " Name:" << name << " Type:" << userType << endl;

                if (!idStr.empty() && !name.empty() && userType == "Admin") {
                    int id = stoi(idStr);
                    Admin* admin = new Admin(id, name, email, password, adminLevel);
                    admins.push_back(admin);
                    adminCount++;
                    cout << "[SUCCESS] Loaded admin: " << name << " (ID: " << id << ")" << endl;
                } else {
                    cout << "[WARNING] Skipped line " << lineNum << " - invalid data" << endl;
                }
            }
            catch (const exception& e) {
                cout << "[WARNING] Failed to parse admin at line " << lineNum << ": " << e.what() << "\n";
            }
        }
        adminFile.close();
        cout << "[SUCCESS] Loaded " << adminCount << " admin(s)\n";
    }
    else {
        cout << "[INFO] admin.txt not found - starting fresh\n";
    }
}

void LMSDatabase::loadStudents() {
    string filePath = PROJECT_DIR + "students.txt";
    ifstream studentFile(filePath);
    if (studentFile.is_open()) {
        string line;
        int lineNum = 0;
        int studentCount = 0;

        while (getline(studentFile, line)) {
            lineNum++;
            if (line.empty()) continue;

            stringstream ss(line);
            string idStr, name, email, password, userType, rollStr, gpaStr;

            try {
                // Parse format: id|name|email|password|Student|rollNumber|gpa|
                getline(ss, idStr, '|');
                getline(ss, name, '|');
                getline(ss, email, '|');
                getline(ss, password, '|');
                getline(ss, userType, '|');
                getline(ss, rollStr, '|');
                getline(ss, gpaStr, '|');

                if (!idStr.empty() && !name.empty() && userType == "Student") {
                    int id = stoi(idStr);
                    int rollNumber = stoi(rollStr);
                    double gpa = stod(gpaStr);

                    Student* student = new Student(id, name, email, password, rollNumber, gpa);
                    students.push_back(student);
                    studentCount++;
                }
            }
            catch (...) {
                cout << "[WARNING] Failed to parse student at line " << lineNum << "\n";
            }
        }
        studentFile.close();
        cout << "[SUCCESS] Loaded " << studentCount << " student(s)\n";
    }
    else {
        cout << "[INFO] students.txt not found - starting fresh\n";
    }
}

void LMSDatabase::loadTeachers() {
    string filePath = PROJECT_DIR + "teachers.txt";
    ifstream teacherFile(filePath);
    if (teacherFile.is_open()) {
        string line;
        int lineNum = 0;
        int teacherCount = 0;

        while (getline(teacherFile, line)) {
            lineNum++;
            if (line.empty()) continue;

            stringstream ss(line);
            string idStr, name, email, password, userType, department, qualification;

            try {
                // Parse format: id|name|email|password|Teacher|department|qualification|
                getline(ss, idStr, '|');
                getline(ss, name, '|');
                getline(ss, email, '|');
                getline(ss, password, '|');
                getline(ss, userType, '|');
                getline(ss, department, '|');
                getline(ss, qualification, '|');

                if (!idStr.empty() && !name.empty() && userType == "Teacher") {
                    int id = stoi(idStr);

                    Teacher* teacher = new Teacher(id, name, email, password, department, qualification);
                    teachers.push_back(teacher);
                    teacherCount++;
                }
            }
            catch (...) {
                cout << "[WARNING] Failed to parse teacher at line " << lineNum << "\n";
            }
        }
        teacherFile.close();
        cout << "[SUCCESS] Loaded " << teacherCount << " teacher(s)\n";
    }
    else {
        cout << "[INFO] teachers.txt not found - starting fresh\n";
    }
}

void LMSDatabase::loadCourses() {
    string filePath = PROJECT_DIR + "courses.txt";
    ifstream courseFile(filePath);
    if (courseFile.is_open()) {
        string line;
        int count = 0;
        while (getline(courseFile, line)) {
            if (line.empty()) continue;
            Course* course = Course::parseCourse(line);
            if (course) {
                courses.push_back(course);
                count++;
            }
        }
        courseFile.close();
        cout << "[SUCCESS] Loaded " << count << " courses.\n";
    } else {
        cout << "[INFO] courses.txt not found - starting fresh\n";
    }
}

void LMSDatabase::loadEnrollments() {
    string filePath = PROJECT_DIR + "enrollments.txt";
    ifstream file(filePath);
    if (file.is_open()) {
        string line;
        int count = 0;
        while (getline(file, line)) {
            if (line.empty()) continue;
            stringstream ss(line);
            string sidStr, cidStr;
            getline(ss, sidStr, '|');
            getline(ss, cidStr, '|');
            
            if (!sidStr.empty() && !cidStr.empty()) {
                int sid = stoi(sidStr);
                int cid = stoi(cidStr);
                
                Student* student = findStudentById(sid);
                Course* course = findCourseById(cid);
                
                if (student && course) {
                    try {
                        student->enrollCourse(course);
                        course->enrollStudent(student);
                        count++;
                    } catch (...) {}
                }
            }
        }
        file.close();
        cout << "[SUCCESS] Restored " << count << " enrollments.\n";
    }
}

void LMSDatabase::loadAssignments() {
    // TODO: Implement assignment loading if needed
}

// ======================= SAVE OPERATIONS =======================

void LMSDatabase::saveAllData() {
    cout << "\n[INFO] Saving all data to files...\n";
    saveAdmins();
    saveStudents();
    saveTeachers();
    saveCourses();
    saveEnrollments();
    cout << "[SUCCESS] All data saved to permanent database!\n";
}

void LMSDatabase::saveAdmins() {
    cout << "[DEBUG] saveAdmins() called" << endl;
    string filePath = PROJECT_DIR + "admin.txt";
    ofstream adminFile(filePath, ios::out | ios::trunc);

    if (!adminFile.is_open()) {
        cerr << "[CRITICAL ERROR] Cannot open admin.txt for writing!" << "\n";
        cerr << "[DEBUG] Check file permissions and directory access." << "\n";
        cerr << "[DEBUG] Current working directory: " << std::filesystem::current_path() << "\n";
        return;
    }

    size_t count = 0;
    for (auto admin : admins) {
        if (admin) {
            // Uses toString(): id|name|email|password|Admin|adminLevel|
            string data = admin->toString();
            adminFile << data << "\n";
            cout << "[DEBUG] Wrote admin: " << data << endl;
            count++;
        }
    }

    // Force write to disk
    adminFile.flush();
    adminFile.close();

    if (adminFile.fail()) {
        cerr << "[ERROR] Failed to write to admin.txt\n";
    }
    else {
        cout << "[INFO] Saved " << count << " admin(s) to admin.txt\n";
    }
}

void LMSDatabase::saveStudents() {
    cout << "[DEBUG] saveStudents() called" << endl;
    string filePath = PROJECT_DIR + "students.txt";
    ofstream studentFile(filePath, ios::out | ios::trunc);

    if (!studentFile.is_open()) {
        cerr << "[CRITICAL ERROR] Cannot open students.txt for writing!" << "\n";
        cerr << "[DEBUG] Check file permissions and directory access." << "\n";
        return;
    }

    size_t count = 0;
    for (auto student : students) {
        if (student) {
            // Uses toString(): id|name|email|password|Student|rollNumber|gpa|
            string data = student->toString();
            studentFile << data << "\n";
            cout << "[DEBUG] Wrote student: " << data << endl;
            count++;
        }
    }

    // Force write to disk
    studentFile.flush();
    studentFile.close();

    if (studentFile.fail()) {
        cerr << "[ERROR] Failed to write to students.txt\n";
    }
    else {
        cout << "[INFO] Saved " << count << " student(s) to students.txt\n";
    }
}

void LMSDatabase::saveTeachers() {
    cout << "[DEBUG] saveTeachers() called" << endl;
    string filePath = PROJECT_DIR + "teachers.txt";
    ofstream teacherFile(filePath, ios::out | ios::trunc);

    if (!teacherFile.is_open()) {
        cerr << "[CRITICAL ERROR] Cannot open teachers.txt for writing!" << "\n";
        cerr << "[DEBUG] Check file permissions and directory access." << "\n";
        return;
    }

    size_t count = 0;
    for (auto teacher : teachers) {
        if (teacher) {
            // Uses toString(): id|name|email|password|Teacher|department|qualification|
            string data = teacher->toString();
            teacherFile << data << "\n";
            cout << "[DEBUG] Wrote teacher: " << data << endl;
            count++;
        }
    }

    // Force write to disk
    teacherFile.flush();
    teacherFile.close();

    if (teacherFile.fail()) {
        cerr << "[ERROR] Failed to write to teachers.txt\n";
    }
    else {
        cout << "[INFO] Saved " << count << " teacher(s) to teachers.txt\n";
    }
}

void LMSDatabase::saveCourses() {
    string filePath = PROJECT_DIR + "courses.txt";
    ofstream file(filePath, ios::out | ios::trunc);
    if (file.is_open()) {
        for (auto course : courses) {
            file << course->toString() << "\n";
        }
        file.close();
        cout << "[INFO] Saved " << courses.size() << " courses.\n";
    }
}

void LMSDatabase::saveEnrollments() {
    string filePath = PROJECT_DIR + "enrollments.txt";
    ofstream file(filePath, ios::out | ios::trunc);
    if (file.is_open()) {
        int count = 0;
        for (auto student : students) {
            if (student) {
                for (auto course : student->getEnrolledCourses()) {
                    if (course) {
                        file << student->getId() << "|" << course->getCourseId() << "\n";
                        count++;
                    }
                }
            }
        }
        file.close();
        cout << "[INFO] Saved " << count << " enrollments.\n";
    }
}

void LMSDatabase::saveAssignments() {
    // TODO: Implement assignment saving if needed
}

// ======================= GETTERS =======================

vector<Admin*>& LMSDatabase::getAdmins() {
    return admins;
}

vector<Student*>& LMSDatabase::getStudents() {
    return students;
}

vector<Teacher*>& LMSDatabase::getTeachers() {
    return teachers;
}

vector<Course*>& LMSDatabase::getCourses() {
    return courses;
}

vector<Assignment*>& LMSDatabase::getAssignments() {
    return assignments;
}

// ======================= FIND OPERATIONS =======================

Admin* LMSDatabase::findAdminByEmail(const string& email) {
    for (auto admin : admins) {
        if (admin && admin->getEmail() == email) {
            return admin;
        }
    }
    return nullptr;
}

Student* LMSDatabase::findStudentByEmail(const string& email) {
    for (auto student : students) {
        if (student && student->getEmail() == email) {
            return student;
        }
    }
    return nullptr;
}

Teacher* LMSDatabase::findTeacherByEmail(const string& email) {
    for (auto teacher : teachers) {
        if (teacher && teacher->getEmail() == email) {
            return teacher;
        }
    }
    return nullptr;
}

Admin* LMSDatabase::findAdminById(int id) {
    for (auto admin : admins) {
        if (admin && admin->getId() == id) {
            return admin;
        }
    }
    return nullptr;
}

Student* LMSDatabase::findStudentById(int id) {
    for (auto student : students) {
        if (student && student->getId() == id) {
            return student;
        }
    }
    return nullptr;
}

Teacher* LMSDatabase::findTeacherById(int id) {
    for (auto teacher : teachers) {
        if (teacher && teacher->getId() == id) {
            return teacher;
        }
    }
    return nullptr;
}

Course* LMSDatabase::findCourseById(int id) {
    for (auto course : courses) {
        if (course && course->getCourseId() == id) {
            return course;
        }
    }
    return nullptr;
}

Assignment* LMSDatabase::findAssignmentById(int id) {
    for (auto assignment : assignments) {
        if (assignment && assignment->getId() == id) {
            return assignment;
        }
    }
    return nullptr;
}

// ======================= ADD OPERATIONS =======================

bool LMSDatabase::addAdmin(Admin* admin) {
    if (admin && isIdUnique(admin->getId()) && isEmailUnique(admin->getEmail())) {
        admins.push_back(admin);
        saveAdmins();
        return true;
    }
    return false;
}

bool LMSDatabase::addStudent(Student* student) {
    if (student && isIdUnique(student->getId()) && isEmailUnique(student->getEmail())) {
        students.push_back(student);
        saveStudents();
        return true;
    }
    return false;
}

bool LMSDatabase::addTeacher(Teacher* teacher) {
    if (teacher && isIdUnique(teacher->getId()) && isEmailUnique(teacher->getEmail())) {
        teachers.push_back(teacher);
        saveTeachers();
        return true;
    }
    return false;
}

bool LMSDatabase::addCourse(Course* course) {
    if (course) {
        courses.push_back(course);
        saveCourses();
        return true;
    }
    return false;
}

bool LMSDatabase::addAssignment(Assignment* assignment) {
    if (assignment) {
        assignments.push_back(assignment);
        saveAssignments();
        return true;
    }
    return false;
}

// ======================= REMOVE OPERATIONS =======================

bool LMSDatabase::removeStudent(int id) {
    auto it = find_if(students.begin(), students.end(),
        [id](Student* s) { return s && s->getId() == id; });
    
    if (it != students.end()) {
        delete *it;
        students.erase(it);
        saveStudents();
        return true;
    }
    return false;
}

bool LMSDatabase::removeTeacher(int id) {
    auto it = find_if(teachers.begin(), teachers.end(),
        [id](Teacher* t) { return t && t->getId() == id; });
    
    if (it != teachers.end()) {
        delete *it;
        teachers.erase(it);
        saveTeachers();
        return true;
    }
    return false;
}

bool LMSDatabase::removeCourse(int id) {
    auto it = find_if(courses.begin(), courses.end(),
        [id](Course* c) { return c && c->getCourseId() == id; });
    
    if (it != courses.end()) {
        delete *it;
        courses.erase(it);
        saveCourses();
        return true;
    }
    return false;
}

// ======================= VALIDATION =======================

bool LMSDatabase::isIdUnique(int id) {
    for (auto admin : admins) {
        if (admin && admin->getId() == id) return false;
    }
    for (auto student : students) {
        if (student && student->getId() == id) return false;
    }
    for (auto teacher : teachers) {
        if (teacher && teacher->getId() == id) return false;
    }
    return true;
}

bool LMSDatabase::isEmailUnique(const string& email) {
    for (auto admin : admins) {
        if (admin && admin->getEmail() == email) return false;
    }
    for (auto student : students) {
        if (student && student->getEmail() == email) return false;
    }
    for (auto teacher : teachers) {
        if (teacher && teacher->getEmail() == email) return false;
    }
    return true;
}

int LMSDatabase::generateUniqueId() {
    int maxId = 0;
    for (auto admin : admins) {
        if (admin && admin->getId() > maxId) maxId = admin->getId();
    }
    for (auto student : students) {
        if (student && student->getId() > maxId) maxId = student->getId();
    }
    for (auto teacher : teachers) {
        if (teacher && teacher->getId() > maxId) maxId = teacher->getId();
    }
    return maxId + 1;
}

// ======================= CLEANUP =======================

void LMSDatabase::cleanup() {
    for (auto admin : admins) {
        delete admin;
    }
    admins.clear();

    for (auto student : students) {
        delete student;
    }
    students.clear();

    for (auto teacher : teachers) {
        delete teacher;
    }
    teachers.clear();

    for (auto course : courses) {
        delete course;
    }
    courses.clear();

    for (auto assignment : assignments) {
        delete assignment;
    }
    assignments.clear();
}
