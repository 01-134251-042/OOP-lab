#include "Assignment.h"
#include <fstream>
#include <sstream>
#include <iostream>

Assignment::Assignment(int id, string title, string deadline, int courseId, float marks)
    : assignmentId(id), title(title), deadline(deadline), courseId(courseId), totalMarks(marks) {

    if (id < 0) throw invalid_argument("ERROR: Assignment ID cannot be negative");
    if (title.empty()) throw invalid_argument("ERROR: Assignment title cannot be empty");
    if (marks < 0 || marks > 100) throw invalid_argument("ERROR: Total marks must be 0-100");
}

Assignment::~Assignment() {}

int Assignment::getId() const { return assignmentId; }
string Assignment::getTitle() const { return title; }
string Assignment::getDeadline() const { return deadline; }
int Assignment::getCourseId() const { return courseId; }
float Assignment::getTotalMarks() const { return totalMarks; }

void Assignment::setTitle(string t) {
    if (t.empty()) throw invalid_argument("ERROR: Title cannot be empty");
    title = t;
}

void Assignment::setDeadline(string d) {
    if (d.empty()) throw invalid_argument("ERROR: Deadline cannot be empty");
    deadline = d;
}

void Assignment::setTotalMarks(float m) {
    if (m < 0 || m > 100) throw invalid_argument("ERROR: Marks must be 0-100");
    totalMarks = m;
}

void Assignment::displayAssignmentInfo() const {
    cout << "\n*******************************************\n";
    cout << "\n --- ASSIGNMENT INFO ---               \n";
    cout << "\n ID: " << assignmentId << "\n";
    cout << "\n Title: " << title << "\n";
    cout << "\n Deadline: " << deadline << "\n";
    cout << "\n Course ID: " << courseId << "\n";
    cout << "\n Total Marks: " << totalMarks << "\n";
    cout << "\n*******************************************";
}

string Assignment::toString() const {
    stringstream ss;
    ss << assignmentId << "|" << title << "|" << deadline << "|" << courseId << "|" << totalMarks;
    return ss.str();
}

Assignment* Assignment::parseAssignment(string line) {
    stringstream ss(line);
    int id, courseId;
    string title, deadline;
    float marks;
    char delim;

    try {
        ss >> id >> delim;
        getline(ss, title, '|');
        getline(ss, deadline, '|');
        ss >> courseId >> delim >> marks;
        return new Assignment(id, title, deadline, courseId, marks);
    }
    catch (...) {
        return nullptr;
    }
}