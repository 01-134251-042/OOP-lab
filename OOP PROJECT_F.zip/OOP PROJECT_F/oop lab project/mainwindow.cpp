#include "mainwindow.h"
#include "logindialog.h"
#include "admindashboard.h"
#include "studentdashboard.h"
#include "teacherdashboard.h"
#include "lmsdatabase.h"
#include <QVBoxLayout>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), currentUser(nullptr),
      adminDashboard(nullptr), studentDashboard(nullptr), teacherDashboard(nullptr)
{
    setupUI();
    showLoginDialog();
}

MainWindow::~MainWindow() {
    // Dashboards are deleted by Qt parent-child relationship
}

void MainWindow::setupUI() {
    setWindowTitle("Learning Management System");
    setMinimumSize(1200, 800);
    
    // Create central widget with stacked layout
    stackedWidget = new QStackedWidget(this);
    setCentralWidget(stackedWidget);
}

void MainWindow::showLoginDialog() {
    LoginDialog* loginDialog = new LoginDialog(this);
    connect(loginDialog, &LoginDialog::loginSuccessful, this, &MainWindow::onLoginSuccess);
    
    if (loginDialog->exec() == QDialog::Rejected) {
        // User closed login dialog, exit application
        close();
    }
}

void MainWindow::onLoginSuccess(User* user) {
    currentUser = user;
    
    if (!currentUser) {
        QMessageBox::critical(this, "Error", "Login failed!");
        return;
    }
    
    // Clear existing dashboards
    while (stackedWidget->count() > 0) {
        QWidget* widget = stackedWidget->widget(0);
        stackedWidget->removeWidget(widget);
        delete widget;
    }
    
    // Create appropriate dashboard based on user type
    if (Admin* admin = dynamic_cast<Admin*>(currentUser)) {
        adminDashboard = new AdminDashboard(admin, this);
        connect(adminDashboard, &AdminDashboard::logoutRequested, this, &MainWindow::onLogout);
        stackedWidget->addWidget(adminDashboard);
        stackedWidget->setCurrentWidget(adminDashboard);
    }
    else if (Student* student = dynamic_cast<Student*>(currentUser)) {
        studentDashboard = new StudentDashboard(student, this);
        connect(studentDashboard, &StudentDashboard::logoutRequested, this, &MainWindow::onLogout);
        stackedWidget->addWidget(studentDashboard);
        stackedWidget->setCurrentWidget(studentDashboard);
    }
    else if (Teacher* teacher = dynamic_cast<Teacher*>(currentUser)) {
        teacherDashboard = new TeacherDashboard(teacher, this);
        connect(teacherDashboard, &TeacherDashboard::logoutRequested, this, &MainWindow::onLogout);
        stackedWidget->addWidget(teacherDashboard);
        stackedWidget->setCurrentWidget(teacherDashboard);
    }
}

void MainWindow::onLogout() {
    // Save all data before logout
    LMSDatabase::getInstance()->saveAllData();
    
    currentUser = nullptr;
    
    // Clear dashboards
    while (stackedWidget->count() > 0) {
        QWidget* widget = stackedWidget->widget(0);
        stackedWidget->removeWidget(widget);
        delete widget;
    }
    
    adminDashboard = nullptr;
    studentDashboard = nullptr;
    teacherDashboard = nullptr;
    
    // Show login dialog again
    showLoginDialog();
}
