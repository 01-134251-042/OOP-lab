#ifndef STUDENT_H
#define STUDENT_H

#include "User.h"
#include <vector>

class Course;
class Assignment;

class Student : public User {
private:
    int rollNumber;
    float gpa;
    vector<Course*> enrolledCourses;  // Aggregation
    vector<Assignment*> submissions;   // Aggregation

public:
    Student(int id = 0, string name = "", string email = "",
        string password = "", int rollNumber = 0, float gpa = 3.5);

    virtual ~Student();

    int getRollNumber() const;
    float getGPA() const;
    vector<Course*> getEnrolledCourses() const;

    void setGPA(float g);
    void setRollNumber(int rn);

    // Functionality 1: View Enrolled Courses
    void viewEnrolledCourses() const;

    // Functionality 2: Download Notes
    void downloadNotes(int courseId);

    // Functionality 3: Submit Assignment
    void submitAssignment(int assignmentId, string file);

    // Functionality 4: View Marks
    void viewMarks() const;

    // Functionality 5: Enroll in Course
    void enrollCourse(Course* course);
    void dropCourse(Course* course);

    // Polymorphism - Override virtual functions
    virtual void login() override;
    virtual void displayDashboard() override;
    virtual void displayMenu() override;

    virtual string toString() const override;
    static Student* parseStudent(string line);

};

#endif // STUDENT_H#pragma once
