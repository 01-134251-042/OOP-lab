#ifndef USER_H
#define USER_H

#include <string>
#include <iostream>
#include <stdexcept>

using namespace std;

class User {
protected:
    int id;
    string name;
    string email;
    string password;
    string userType;

public:
    // Constructor
    User(int id = 0, string name = "", string email = "",
        string password = "", string userType = "");

    // Virtual Destructor
    virtual ~User();

    // Getters (Encapsulation)
    int getId() const;
    string getName() const;
    string getEmail() const;
    string getPassword() const;
    string getUserType() const;

    // Setters with validation
    void setName(string name);
    void setEmail(string email);
    void setPassword(string password);

    // Validation functions
    bool validateEmail(string email) const;
    bool validatePassword(string password) const;
    bool validateName(string name) const;

    // Pure virtual functions - Polymorphism
    virtual void login() = 0;
    virtual void displayDashboard() = 0;
    virtual void displayMenu() = 0;

    // File operations
    virtual string toString() const;
    static User* parseUser(string line);
};

#endif // USER_H#pragma once
