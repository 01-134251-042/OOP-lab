#include "studentdashboard.h"
#include "lmsdatabase.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QHeaderView>
#include <QMessageBox>
#include <QInputDialog>
#include <QGroupBox>
#include <fstream>
#include <sstream>

StudentDashboard::StudentDashboard(Student* student, QWidget *parent)
    : QWidget(parent), currentStudent(student)
{
    setupUI();
    applyStyles();
    refreshData();
}

StudentDashboard::~StudentDashboard() {
}

void StudentDashboard::setupUI() {
    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(20);
    mainLayout->setContentsMargins(30, 30, 30, 30);
    
    // Welcome header
    welcomeLabel = new QLabel(QString("Welcome, %1").arg(QString::fromStdString(currentStudent->getName())), this);
    welcomeLabel->setObjectName("welcomeLabel");
    mainLayout->addWidget(welcomeLabel);
    
    // GPA label
    gpaLabel = new QLabel(QString("📚 Your GPA: %1 | Roll Number: %2")
        .arg(currentStudent->getGPA(), 0, 'f', 2)
        .arg(currentStudent->getRollNumber()), this);
    gpaLabel->setObjectName("gpaLabel");
    mainLayout->addWidget(gpaLabel);
    
    // Action buttons
    QGroupBox* actionsGroup = new QGroupBox("Student Actions", this);
    QGridLayout* buttonGrid = new QGridLayout(actionsGroup);
    buttonGrid->setSpacing(15);
    
    enrollCourseBtn = new QPushButton("➕ Enroll in Course", this);
    enrollCourseBtn->setObjectName("enrollCourseBtn");
    enrollCourseBtn->setToolTip("Enroll in a new course");
    buttonGrid->addWidget(enrollCourseBtn, 0, 0);
    
    dropCourseBtn = new QPushButton("➖ Drop Course", this);
    dropCourseBtn->setObjectName("dropCourseBtn");
    dropCourseBtn->setToolTip("Drop an enrolled course");
    buttonGrid->addWidget(dropCourseBtn, 0, 1);
    
    viewMarksBtn = new QPushButton("📊 View Marks", this);
    viewMarksBtn->setObjectName("viewMarksBtn");
    viewMarksBtn->setToolTip("View your marks and grades");
    buttonGrid->addWidget(viewMarksBtn, 1, 0);
    
    submitAssignmentBtn = new QPushButton("📝 Submit Assignment", this);
    submitAssignmentBtn->setToolTip("Submit an assignment");
    buttonGrid->addWidget(submitAssignmentBtn, 1, 1);
    
    downloadNotesBtn = new QPushButton("📥 Download Notes", this);
    downloadNotesBtn->setToolTip("Download course notes");
    buttonGrid->addWidget(downloadNotesBtn, 2, 0);
    
    logoutBtn = new QPushButton("🚪 Logout", this);
    logoutBtn->setObjectName("logoutBtn");
    logoutBtn->setToolTip("Logout from student panel");
    buttonGrid->addWidget(logoutBtn, 2, 1);
    
    mainLayout->addWidget(actionsGroup);
    
    // Enrolled courses list
    QGroupBox* coursesGroup = new QGroupBox("My Enrolled Courses", this);
    QVBoxLayout* coursesLayout = new QVBoxLayout(coursesGroup);
    
    coursesList = new QListWidget(this);
    coursesLayout->addWidget(coursesList);
    
    mainLayout->addWidget(coursesGroup);
    
    // Marks table
    QGroupBox* marksGroup = new QGroupBox("My Marks", this);
    QVBoxLayout* marksLayout = new QVBoxLayout(marksGroup);
    
    marksTable = new QTableWidget(this);
    marksTable->setColumnCount(4);
    marksTable->setHorizontalHeaderLabels({"Course", "Assignment", "Marks", "Status"});
    marksTable->horizontalHeader()->setStretchLastSection(true);
    marksTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    marksTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    marksTable->setAlternatingRowColors(true);
    marksLayout->addWidget(marksTable);
    
    mainLayout->addWidget(marksGroup);
    
    // Connect signals
    connect(enrollCourseBtn, &QPushButton::clicked, this, &StudentDashboard::onEnrollCourseClicked);
    connect(dropCourseBtn, &QPushButton::clicked, this, &StudentDashboard::onDropCourseClicked);
    connect(viewMarksBtn, &QPushButton::clicked, this, &StudentDashboard::onViewMarksClicked);
    connect(submitAssignmentBtn, &QPushButton::clicked, this, &StudentDashboard::onSubmitAssignmentClicked);
    connect(downloadNotesBtn, &QPushButton::clicked, this, &StudentDashboard::onDownloadNotesClicked);
    connect(logoutBtn, &QPushButton::clicked, this, &StudentDashboard::onLogoutClicked);
}

void StudentDashboard::applyStyles() {
    // Styles applied via global stylesheet
}

void StudentDashboard::refreshData() {
    updateCourseList();

    // Refresh marks table from file
    onViewMarksClicked();
}

void StudentDashboard::updateCourseList() {
    coursesList->clear();
    
    auto enrolledCourses = currentStudent->getEnrolledCourses();
    
    if (enrolledCourses.empty()) {
        coursesList->addItem("No courses enrolled yet. Click 'Enroll in Course' to get started!");
    } else {
        for (Course* course : enrolledCourses) {
            if (course) {
                QString courseInfo = QString("📖 %1 (ID: %2)")
                    .arg(QString::fromStdString(course->getCourseTitle()))
                    .arg(course->getCourseId());
                coursesList->addItem(courseInfo);
            }
        }
    }
}

void StudentDashboard::onEnrollCourseClicked() {
    bool ok = false;
    int courseId = QInputDialog::getInt(
        this,
        "Enroll in Course",
        "Enter Course ID to enroll:",
        0,
        0,
        999999,
        1,
        &ok);

    if (!ok) return;

    LMSDatabase* db = LMSDatabase::getInstance();
    Course* course = db->findCourseById(courseId);

    if (!course) {
        QMessageBox::warning(this, "Course Not Found",
                             "No course found with the given ID.");
        return;
    }

    try {
        course->enrollStudent(currentStudent);
        currentStudent->enrollCourse(course);
        db->saveEnrollments(); // Save changes
        QMessageBox::information(this, "Enrolled",
                                 "You have been enrolled in the course successfully.");
        refreshData();
    } catch (const std::exception& ex) {
        QMessageBox::warning(this, "Enroll Failed", ex.what());
    }
}

void StudentDashboard::onDropCourseClicked() {
    if (coursesList->currentRow() < 0) {
        QMessageBox::warning(this, "No Selection", "Please select a course to drop.");
        return;
    }
    
    auto reply = QMessageBox::question(this, "Drop Course", 
        "Are you sure you want to drop this course?",
        QMessageBox::Yes | QMessageBox::No);
    
    if (reply != QMessageBox::Yes) {
        return;
    }

    auto enrolledCourses = currentStudent->getEnrolledCourses();
    int index = coursesList->currentRow();

    if (index < 0 || index >= static_cast<int>(enrolledCourses.size())) {
        QMessageBox::warning(this, "Error", "Invalid course selection.");
        return;
    }

    Course* course = enrolledCourses[index];
    if (!course) {
        QMessageBox::warning(this, "Error", "Selected course is invalid.");
        return;
    }

    try {
        course->removeStudent(currentStudent->getId());
        currentStudent->dropCourse(course);
        LMSDatabase::getInstance()->saveEnrollments(); // Save changes
        QMessageBox::information(this, "Course Dropped", "Course dropped successfully!");
        refreshData();
    } catch (const std::exception& ex) {
        QMessageBox::warning(this, "Drop Failed", ex.what());
    }
}

void StudentDashboard::onViewMarksClicked() {
    // Clear existing rows
    marksTable->setRowCount(0);

    const std::string projectDir = "D:/OOP PROJECT_F/oop lab project/";
    std::ifstream marksFile(projectDir + "marks.txt");

    if (!marksFile.is_open()) {
        currentStudent->viewMarks();
        return;
    }

    std::string line;
    int studentId = currentStudent->getId();

    LMSDatabase* db = LMSDatabase::getInstance();

    while (std::getline(marksFile, line)) {
        if (line.empty()) continue;

        std::stringstream ss(line);
        std::string sidStr, assignmentIdStr, obtainedStr, courseIdStr;

        std::getline(ss, sidStr, '|');
        std::getline(ss, assignmentIdStr, '|');
        std::getline(ss, obtainedStr, '|');
        std::getline(ss, courseIdStr, '|');

        if (sidStr.empty()) continue;

        int sid = std::stoi(sidStr);
        if (sid != studentId) continue;

        int assignmentId = std::stoi(assignmentIdStr);
        int courseId = std::stoi(courseIdStr);

        Assignment* assignment = db->findAssignmentById(assignmentId);
        Course* course = db->findCourseById(courseId);

        int row = marksTable->rowCount();
        marksTable->insertRow(row);

        QString courseName = course
            ? QString::fromStdString(course->getCourseTitle())
            : QString("Course %1").arg(courseId);
        QString assignmentTitle = assignment
            ? QString::fromStdString(assignment->getTitle())
            : QString("Assignment %1").arg(assignmentId);

        marksTable->setItem(row, 0, new QTableWidgetItem(courseName));
        marksTable->setItem(row, 1, new QTableWidgetItem(assignmentTitle));
        marksTable->setItem(row, 2, new QTableWidgetItem(
                                    QString("%1/100").arg(QString::fromStdString(obtainedStr))));
        marksTable->setItem(row, 3, new QTableWidgetItem("✅ Graded"));
    }

    if (marksTable->rowCount() == 0) {
        int row = marksTable->rowCount();
        marksTable->insertRow(row);
        marksTable->setItem(row, 0, new QTableWidgetItem("No records"));
        marksTable->setItem(row, 1, new QTableWidgetItem("-"));
        marksTable->setItem(row, 2, new QTableWidgetItem("-"));
        marksTable->setItem(row, 3, new QTableWidgetItem("No marks available"));
    }
}

void StudentDashboard::onSubmitAssignmentClicked() {
    bool okId = false;
    int assignmentId = QInputDialog::getInt(
        this,
        "Submit Assignment",
        "Enter Assignment ID:",
        0,
        0,
        999999,
        1,
        &okId);

    if (!okId) return;

    bool okFile = false;
    QString filePath = QInputDialog::getText(
        this,
        "Submit Assignment",
        "Enter file name or path (for record only):",
        QLineEdit::Normal,
        "",
        &okFile);

    if (!okFile || filePath.trimmed().isEmpty()) {
        QMessageBox::warning(this, "Invalid Input", "File path cannot be empty.");
        return;
    }

    try {
        currentStudent->submitAssignment(assignmentId, filePath.toStdString());
        QMessageBox::information(this, "Submitted",
                                 "Your assignment submission has been recorded.");
    } catch (const std::exception& ex) {
        QMessageBox::warning(this, "Submission Failed", ex.what());
    }
}

void StudentDashboard::onDownloadNotesClicked() {
    bool ok = false;
    int courseId = QInputDialog::getInt(
        this,
        "Download Notes",
        "Enter Course ID:",
        0,
        0,
        999999,
        1,
        &ok);

    if (!ok) return;

    try {
        currentStudent->downloadNotes(courseId);
        QMessageBox::information(this, "Notes Downloaded",
                                 "Notes file has been created in the project folder.");
    } catch (const std::exception& ex) {
        QMessageBox::warning(this, "Download Failed", ex.what());
    }
}

void StudentDashboard::onLogoutClicked() {
    auto reply = QMessageBox::question(this, "Logout", "Are you sure you want to logout?",
                                      QMessageBox::Yes | QMessageBox::No);
    if (reply == QMessageBox::Yes) {
        emit logoutRequested();
    }
}
