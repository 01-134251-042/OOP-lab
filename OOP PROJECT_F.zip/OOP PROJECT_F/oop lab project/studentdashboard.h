#ifndef STUDENTDASHBOARD_H
#define STUDENTDASHBOARD_H

#include <QWidget>
#include <QPushButton>
#include <QTableWidget>
#include <QLabel>
#include <QListWidget>
#include "student.h"

class StudentDashboard : public QWidget {
    Q_OBJECT

public:
    explicit StudentDashboard(Student* student, QWidget *parent = nullptr);
    ~StudentDashboard();
    
    void refreshData();

signals:
    void logoutRequested();

private slots:
    void onEnrollCourseClicked();
    void onDropCourseClicked();
    void onViewMarksClicked();
    void onSubmitAssignmentClicked();
    void onDownloadNotesClicked();
    void onLogoutClicked();

private:
    void setupUI();
    void applyStyles();
    void updateCourseList();
    
    Student* currentStudent;
    
    QLabel* welcomeLabel;
    QLabel* gpaLabel;
    QPushButton* enrollCourseBtn;
    QPushButton* dropCourseBtn;
    QPushButton* viewMarksBtn;
    QPushButton* submitAssignmentBtn;
    QPushButton* downloadNotesBtn;
    QPushButton* logoutBtn;
    QListWidget* coursesList;
    QTableWidget* marksTable;
};

#endif // STUDENTDASHBOARD_H
