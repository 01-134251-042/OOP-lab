#ifndef TEACHERDASHBOARD_H
#define TEACHERDASHBOARD_H

#include <QWidget>
#include <QPushButton>
#include <QTableWidget>
#include <QLabel>
#include <QListWidget>
#include "teacher.h"

class TeacherDashboard : public QWidget {
    Q_OBJECT

public:
    explicit TeacherDashboard(Teacher* teacher, QWidget *parent = nullptr);
    ~TeacherDashboard();
    
    void refreshData();

signals:
    void logoutRequested();

private slots:
    void onCreateCourseClicked();
    void onCreateAssignmentClicked();
    void onUploadNotesClicked();
    void onGiveMarksClicked();
    void onViewStudentsClicked();
    void onLogoutClicked();

private:
    void setupUI();
    void applyStyles();
    void updateCourseList();
    
    Teacher* currentTeacher;
    
    QLabel* welcomeLabel;
    QLabel* departmentLabel;
    QPushButton* createCourseBtn;
    QPushButton* createAssignmentBtn;
    QPushButton* uploadNotesBtn;
    QPushButton* giveMarksBtn;
    QPushButton* viewStudentsBtn;
    QPushButton* logoutBtn;
    QListWidget* coursesList;
    QTableWidget* studentsTable;
};

#endif // TEACHERDASHBOARD_H
