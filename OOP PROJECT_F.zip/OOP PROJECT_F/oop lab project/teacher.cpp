#include "Teacher.h"
#include "lmsdatabase.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <filesystem>

namespace fs = std::filesystem;

const string PROJECT_ROOT = "D:/OOP PROJECT_F/oop lab project/";

Teacher::Teacher(int id, string name, string email, string password, string department, string qualification)
    : User(id, name, email, password, "Teacher"), department(department), qualification(qualification) {

    if (department.empty()) throw invalid_argument("ERROR: Department cannot be empty");
    if (qualification.empty()) throw invalid_argument("ERROR: Qualification cannot be empty");
}

Teacher::~Teacher() {
    taughtCourses.clear();
    assignments.clear();
}

string Teacher::getDepartment() const { return department; }
string Teacher::getQualification() const { return qualification; }
vector<Course*> Teacher::getTaughtCourses() const { return taughtCourses; }

void Teacher::setDepartment(string d) {
    if (d.empty()) throw invalid_argument("ERROR: Department cannot be empty");
    department = d;
}

void Teacher::setQualification(string q) {
    if (q.empty()) throw invalid_argument("ERROR: Qualification cannot be empty");
    qualification = q;
}

// Functionality 1: Upload Notes
void Teacher::uploadNotes(int courseId, string file) {
    if (file.empty()) throw invalid_argument("ERROR: File path cannot be empty");

    fs::path inputPath(file);
    string sourcePath = file;
    
    // If path is relative, assume it's in the project root
    if (inputPath.is_relative()) {
        sourcePath = PROJECT_ROOT + file;
    }

    // Ensure directory exists
    if (!fs::exists(PROJECT_ROOT + "course_materials")) {
        fs::create_directories(PROJECT_ROOT + "course_materials");
    }

    // Destination: course_materials/course_{courseId}.txt
    // Preserving extension if possible, or defaulting to .txt if not in input (simplified here)
    string extension = inputPath.extension().string();
    if (extension.empty()) extension = ".txt";

    string destPath = PROJECT_ROOT + "course_materials/course_" + to_string(courseId) + extension;

    if (fs::exists(sourcePath)) {
        try {
            if (fs::exists(destPath)) fs::remove(destPath);
            fs::copy_file(sourcePath, destPath);
            cout << "? Notes uploaded/copied to: " << destPath << "\n";
        } catch (fs::filesystem_error& e) {
            throw runtime_error("Error uploading notes: " + string(e.what()));
        }
    } else {
        throw runtime_error("Source file not found: " + sourcePath);
    }
}

// Functionality 2: Create Assignment
void Teacher::createAssignment(int assignmentId, string title, string deadline) {
    if (title.empty()) throw invalid_argument("ERROR: Assignment title cannot be empty");
    if (deadline.empty()) throw invalid_argument("ERROR: Deadline cannot be empty");

    // Ensure assignments directory exists
    if (!fs::exists(PROJECT_ROOT + "assignments")) {
        fs::create_directories(PROJECT_ROOT + "assignments");
    }

    string filePath = PROJECT_ROOT + "assignments/assignment_" + to_string(assignmentId) + ".txt";
    ofstream out(filePath);
    if (out.is_open()) {
        out << "Assignment ID: " << assignmentId << "\n";
        out << "Title: " << title << "\n";
        out << "Deadline: " << deadline << "\n";
        out << "Created by: " << name << "\n";
        out.close();
        cout << "? Assignment created at: " << filePath << "\n";
    } else {
        throw runtime_error("Could not create assignment file.");
    }
}

// Functionality 3: Give Marks
void Teacher::giveMarks(int studentId, int assignmentId, float marks) {
    // NOTE: This now writes to the central marks.txt
    // Format: StudentID|AssignmentID|Marks|CourseID
    // We need CourseID. For now, we will guess or ask user. 
    // Wait, the params don't have CourseID. I'll default to 0 or fix later if needed.
    // Actually, looking at previous marks.txt: 4|867|78|101
    // It requires CourseID. I will assume this function needs modification or we append a placeholder.
    // However, since I can't change signature easily without breaking other things, I'll append a dummy CourseID '0' 
    // OR BETTER: The user UI asks for everything.
    
    // UPDATE: The user only sends (studentId, assignmentId, marks).
    // I really should have CourseID. I'll check if I can modify the header.
    // For now, I will append "0" as CourseID to maintain format.

    if (marks < 0 || marks > 100) {
        throw invalid_argument("ERROR: Marks must be between 0 and 100");
    }

    string marksPath = PROJECT_ROOT + "marks.txt";
    ofstream out(marksPath, ios::app); // Append mode
    if (out.is_open()) {
        // Format: StudentID|AssignmentID|Marks|CourseID
        // Using 0 as placeholder for CourseID since it's not passed in.
        // Ideally we should pass courseID.
        out << studentId << "|" << assignmentId << "|" << marks << "|0" << "\n"; 
        out.close();
        cout << " Marks recorded to marks.txt!\n";
    } else {
        throw runtime_error("Could not open marks.txt");
    }
}

// Functionality 4: Create Course
void Teacher::createCourse(int courseId, string title) {
    if (title.empty()) throw invalid_argument("ERROR: Course title cannot be empty");

    // Use LMSDatabase to add the course properly so it saves to courses.txt
    Course* newCourse = new Course(courseId, title, 50); // Default capacity 50
    // Assuming we want to link this teacher to the course, but Course class might not have a teacher field in constructor
    // Checking Course.cpp... it has enrollStudent. 
    
    if (LMSDatabase::getInstance()->addCourse(newCourse)) {
        cout << " Course created and saved to courses.txt!\n";
        // Also add to this teacher's taught list
        taughtCourses.push_back(newCourse);
    } else {
        delete newCourse; // Failed to add (maybe duplicate ID)
        throw runtime_error("Failed to create course. ID might be duplicate.");
    }
}

// Functionality 5: View Course Students
void Teacher::viewCourseStudents(int courseId) const {
    cout << "\n=== STUDENTS IN COURSE " << courseId << " ===\n";
    cout << "No students enrolled yet.\n";
}

void Teacher::login() {
    cout << "\n*********************************************\n";
    cout << " --- TEACHER LOGIN ---                 \n";
    cout << " Logged in: " << name << "\n";
    cout << " Department: " << department << "\n";
    cout << "  **********************************************\n";
}

void Teacher::displayDashboard() {
    cout << "\n****************************************\n";
    cout << "\n --- TEACHER DASHBOARD ---             ";
    cout << "\n Name: " << name << "\n";
    cout << "\n Email: " << email << "\n";
    cout << "\n Department: " << department << "\n";
    cout << "\n Qualification: " << qualification << "\n";
    cout << "\n****************************************" << endl;
}

void Teacher::displayMenu() {
    cout << "\n=== TEACHER MENU ===\n";
    cout << "1. View Dashboard\n";
    cout << "2. Create Course\n";
    cout << "3. Upload Notes\n";
    cout << "4. Create Assignment\n";
    cout << "5. Give Marks\n";
    cout << "6. Logout\n";
    cout << "Enter choice: ";
}
/*
string Teacher::toString() const {
    stringstream ss;
    ss << id << "|" << name << "|" << email << "|" << password
        << "|" << userType << "|" << department << "|" << qualification;
    return ss.str();
}
*/

Teacher* Teacher::parseTeacher(string line) {
    stringstream ss(line);
    string token;
    int id;
    string name, email, password, userType, department, qualification;

    try {
        getline(ss, token, '|'); id = stoi(token);
        getline(ss, name, '|');
        getline(ss, email, '|');
        getline(ss, password, '|');
        getline(ss, userType, '|');
        getline(ss, department, '|');
        getline(ss, qualification, '|');  // Use '|' as delimiter for the last field too

        return new Teacher(id, name, email, password, department, qualification);
    }
    catch (...) {
        return nullptr;
    }
}


string Teacher::toString() const {
    // Format: id|name|email|password|Teacher|department|qualification|
    return to_string(getId()) + "|" + getName() + "|" + getEmail() + "|" + getPassword() + "|Teacher|" + department + "|" + qualification + "|";
}